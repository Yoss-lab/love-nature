<?php 
session_start();
if(!empty($_SESSION['Souser20']))
{
    header("Location:dashboard-insights.php");   
}
?>
<!DOCTYPE html>
<html lang="fr">
<?php include("includes/header.php");?>
<body>
    <?php include("includes/menu.php");?>
    <!-- MAIN START -->
    <main class="ps-main">
        <div class="container">
            <div class="row ps-main-section">
                <div class="col-lg-11 col-xl-10">
                    <nav class="ps-login">
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                          <a class="nav-item nav-link active" id="nav-login-tab" data-toggle="tab" href="#nav-login" role="tab" aria-controls="nav-login" aria-selected="true">Login</a>
                          <a class="nav-item nav-link" id="nav-register-tab" data-toggle="tab" href="#nav-register" role="tab" aria-controls="nav-register" aria-selected="false">Register</a>
                        </div>
                      </nav>
                      <div class="tab-content" id="nav-tabContent">
                        <?php 
                        if(isset($_POST['submitregister']))
                        {
                                if(empty($_POST['nom']))
                                {
                                    echo '<h4 class="alert_error" style="float:left;">Champ nom est obligatoire</h4>';
                                }
                                if(empty($_POST['prenom']))
                                {
                                    
                                    echo '<h4 class="alert_error" style="float:left;">Champ prenom est obligatoire</h4>';
                                }
                                if(empty($_POST['email']))
                                {
                                    
                                    echo '<h4 class="alert_error" style="float:left;">Champ email est obligatoire</h4>';
                                }
                                if(empty($_POST['login']))
                                {
                                    echo '<h4 class="alert_error" style="float:left;">Champ login est obligatoire</h4>';
                                }
                                if(empty($_POST['motdepasse']) || strlen($_POST['motdepasse'])<4)
                                {
                                    echo '<h4 class="alert_error" style="float:left;">Champ Mot de passe est obligatoire, et supérieur à 4</h4>';
                                }
                                
                                /*text existance login et email*/
                                $sql="SELECT * FROM users WHERE login='".$_POST['login']."' || email='".$_POST['email']."' && statut='annonceur'";
                                $result=mysql_query($sql);
                                $row=mysql_fetch_array($result);
                                if($row['login']==$_POST['login'])
                                {
                                $exist=1;   
                                echo '<h4 class="alert_error" style="float:left;">Login existant, merci de choisir autre.</h4>';
                                }
                                else if($row['nom']==$_POST['nom'] && $row['prenom']==$_POST['prenom'])
                                {
                                    $exist=1;
                                    echo '<h4 class="alert_error" style="float:left;">Nom et Prénom existant, merci de choisir un autre.</h4>';
                                }
                                else if($row['email']==$_POST['email'])
                                {
                                    $exist=1;
                                    echo '<h4 class="alert_error" style="float:left;">Email existant, merci de choisir autre login.</h4>';
                                }
                                else
                                {
                                    $exist=0;   
                                }
                                if($exist==0 && !empty($_POST['nom']) && !empty($_POST['prenom'])&& !empty($_POST['email']) && !empty($_POST['login']) && !empty($_POST['motdepasse']) && strlen($_POST['motdepasse'])>4)
                                {
                                                            
                                    $qid2 = mysql_query("insert into users (nom,prenom,email,login,motpasse,motdepasse,statut,activ) values ('".$_POST['nom']."','".$_POST['prenom']."','".$_POST['email']."','".$_POST['login']."','".md5($_POST['motdepasse'])."','".$_POST['motdepasse']."','annonceur','0')")or DIE('<div class="error">Probl&egrave;me dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
                                    echo '<h4 class="alert_success">Votre Compte a été ajouté avec succés, Merci d\'accéder à votre email pour activer votre compte.</h4>';
                                    session_destroy();
                                    $_SESSION['adminprestige']='';
                                    $from  = "From:contact@soukauto.tn\n";
                                    $from .= "MIME-version: 1.0\n";
                                    $from .= "Content-type: text/html; charset= iso-8859-1\n";
                                                        
                                    $subj="Activation compte annonceur ".$_POST['nom']." ".$_POST['prenom']." souk auto";
                                    mail('contact@soukauto.tn',$subj,"Bonjour, <a href='http://www.soukauto.tn/adminauto/activ.php?m=".$_POST['email']."'>cliquer ici pour activer compte admin souk auto :".$_POST['nom']." ".$_POST['prenom']."</a>",$from);
                                    mail($_POST['email'],$subj,"Bonjour,<br/> Bienvenue Sur Souk Auto Merci de Cliquer sur le lien ci-dessous pour activer votre compte et ajouter des annonce.<br/><a href='http://www.soukauto.tn/adminauto/activ.php?m=".$_POST['email']."'>cliquer ici pour activer compte admin souk auto :".$_POST['nom']." ".$_POST['prenom']."</a><br/><br/> Cordialement",$from);
                                    ?>
                                    <script>setTimeout(function(){location.replace("login.php");},8000);</script>
                                    <?php
                                }           
                        }
                        if(isset($_POST['submit']))
                        {

                            $sql="SELECT * FROM users WHERE login='".$_POST['usere']."' && motdepasse='".$_POST['pwde']."' && statut='annonceur' && activ=1";
                            $result=mysql_query($sql);
                            $row=mysql_fetch_array($result);
                            if($row['login']==$_POST['usere'] && $row['motdepasse']==$_POST['pwde'])
                            {
                                if($row['activ']==1)
                                {
                                    $_SESSION['Souser20']='i'.$row['id'].'-annc';
                                    echo '<h4 class="alert_success">Connexion réussite, dans le bref délai vous aller etre rediriger à votre espace.</h4>';

                                    ?>
                                    <script>setTimeout(function(){location.replace("dashboard-insights.php");},8000);</script>
                                    <?php
                                }
                                else
                                {
                                        echo '<h4 class="alert_success">Votre Compte n\'a pas été activé avec succés, Merci de contacter le service adminsitratif.</h4>';
                                }
                            }    
                            else
                            {
                                        echo '<h4 class="alert_warning">Merci de bien vérifier votre nom d\'utilisateur ou mot de passe!!.</h4>';                                
                            }    

                        }
                        ?><br/>
                        <!-- LOGIN START -->
                        <div class="tab-pane fade show active" id="nav-login" role="tabpanel" aria-labelledby="nav-login-tab">
                            <div class="ps-login__area">
                                <div class="ps-gridList__searchArea ps-contact-seller">
                                    <h6>Login Now</h6>
                                    <form name="login" method="post" action="">
                                        <div class="form-group">
                                            <input name="usere" type="text" class="form-control" id="formGroupExampleInput1" placeholder="Username*" value="">
                                        </div>
                                        <div class="form-group">
                                            <input name="pwde" type="password" class="form-control" id="formGroupExampleInput2" placeholder="Password*" value="">
                                        </div>
                                        <div class="ps-login-btn">
                                            <input name="submit" type="submit" value="Valider" class="btn ps-btn">
                                            <a href="javascript:void(0);">Forgot Your Password?</a>
                                        </div>
                                    </form>
                                </div>
                                <div class="ps-or">
                                    <div></div>
                                    <div>
                                        <h6>OR</h6>
                                    </div>
                                </div>
                                <div class="ps-social-login">
                                    <h6>Login Via Social</h6>
                                    <button class="btn ps-facebook-btn ps-btn"><i class="fab fa-facebook-f"></i><span>Login With Facebook <i class="ti-angle-right"></i></span></button>
                                    <button class="btn ps-twitter-btn ps-btn"><i class="fab fa-twitter"></i><span>Login With Twitter <i class="ti-angle-right"></i></span></button>
                                    <button class="btn ps-google-plusbtn ps-btn"><i class="fab fa-google-plus-g"></i><span>Login With Google <i class="ti-angle-right"></i></span></button>
                                </div>
                            </div>
                        </div>
                        <!-- LOGIN END -->
                        <!-- REGISTER START -->
                        <div class="tab-pane fade" id="nav-register" role="tabpanel" aria-labelledby="nav-register-tab">
                            <div class="ps-login__area">
                                <div class="ps-gridList__searchArea ps-contact-seller">
                                    <h6>Make New Account</h6>
                                    <form name="profil" method="post" action="">
                                        <div class="form-group">
                                            <input type="text" required="" class="form-control" id="formGroupExampleInput3" placeholder="Nom*" name="nom">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" required="" class="form-control" id="formGroupExampleInput3" placeholder="Prenom*" name="prenom">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" required="" class="form-control" id="formGroupExampleInput3" placeholder="Username*" name="login">
                                        </div>
                                        <div class="form-group">
                                            <input type="email" required="" class="form-control" id="formGroupExampleInput4" placeholder="Email*" name="email">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" required="" class="form-control" id="formGroupExampleInput5" placeholder="Password*" name="motdepasse">
                                        </div>
                                        <div class="ps-login-btn">
                                            <input name="submitregister" type="submit" value="Valider" class="btn ps-btn">
                                        </div>
                                    </form>
                                </div>
                                <div class="ps-or">
                                    <div></div>
                                    <div>
                                        <h6>OR</h6>
                                    </div>
                                </div>
                                <div class="ps-social-login">
                                    <h6>Register Via Social</h6>
                                    <button class="btn ps-facebook-btn ps-btn"><i class="fab fa-facebook-f"></i><span>Login With Facebook <i class="ti-angle-right"></i></span></button>
                                    <button class="btn ps-twitter-btn ps-btn"><i class="fab fa-twitter"></i><span>Login With Twitter <i class="ti-angle-right"></i></span></button>
                                    <button class="btn ps-google-plusbtn ps-btn"><i class="fab fa-google-plus-g"></i><span>Login With Google <i class="ti-angle-right"></i></span></button>
                                </div>
                            </div>    
                        </div>
                        <!-- REGISTER END -->
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- MAIN END -->
    <?php include("includes/footer.php");?>
</body>
</html>