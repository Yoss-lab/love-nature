<!DOCTYPE html>
<html lang="fr">
<?php include("includes/header.php");?>
<body>
    <?php include("includes/menu.php");?>
    <!-- MAIN START -->
    <main class="ps-main">
        <!-- MOTIVE START -->
        <section class="container">
            <div class="row ps-main-section ps-motive">
                <div class="col-lg-5">
                    <figure class="ps-img-mask animate" data-animate="fadeInLeft">
                        <img class="ps-original" src="images/about-page/img-03.jpg" alt="Image Description">
                        <img class="ps-dotted-img" src="images/about-page/img-04.png" alt="">
                    </figure>
                    <svg id="Image" xmlns="http://www.w3.org/2000/svg" width="0" height="0">
                      <defs>
                          <clipPath id="mask">
                              <path d="M306.218,61.582c95.036,54.87,175.554,126.795,120.685,221.831S181.64,496.834,86.6,441.966-22.84,150.469,32.029,55.433,211.182,6.714,306.218,61.582Z"/>
                          </clipPath>
                        </defs>
                      </svg>
                </div>
                <div class="col-lg-6">
                    <div class="animate" data-animate="fadeInRight">
                        <h4><span class="d-block">Our Motive Is To Provide Best</span>For Those Who Deserve</h4>
                        <p>Consectetur adipisicing elit sed do eiusmode tempor incididunt utebore duis autie irure dolor inte reprehenderit in voluptate velition cillum nulla pariatur excepteur sinteon proident sunt.</p>
                        <p>Culpa qui officia deserunt mollit anim id estborum sed utren perspiciatis unde omnis tus error voluptatem accusantium doloremque laudantiumi totam rem aperiam eaque ipsa quae ab illoam inventore veritatis etquas
                            architecto beatae vitae dicta sunt explicabo enim ipsam.</p>
                        <div class="ps-motive__icon">
                            <figure><img src="images/about-page/img-02.jpg" alt="Image Description"></figure>
                            <div class="ps-motive__icon-text">
                                <h6>Wilfredo Taormina<span class="d-block">Founder & C.E.O</span></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- MOTIVE END -->
        <!-- STATUS START -->
        <section class="ps-main-section ps-status">
            <div class="container">
                <div class="ps-center-content">
                    <div class="ps-center-description">
                        <h6 class="animate" data-animate="swoopInLeft">Why We’re Best</h6>
                        <h4 class="animate" data-animate="swoopInRight">Stat Says It All</h4>
                        <p class="animate" data-animate="fadeIn">Consectetur adipisicing eliteiuim set eiusmod tempor incididunt labore etnalom dolore magna aliqua udiminimate veniam quistan norud.</p>
                    </div>
                    <div class="ps-status__content" id="counter">
                        <div class="ps-status__item">
                            <div class="ps-status__img">
                                <figure><img src="images/ps-status/img-01.png" alt="Image Description"></figure>
                            </div>
                            <div class="ps-status__title">
                                <h5><span class="count" data-count="35">0</span>,<span class="count" data-count="6820"></span></h5>
                                <h6>Active Items</h6>
                            </div>
                        </div>
                        <div class="ps-status__item">
                            <div class="ps-status__img">
                                <figure><img src="images/ps-status/img-02.png" alt="Image Description"></figure>
                            </div>
                            <div class="ps-status__title">
                                <h5><span class="count" data-count="99.56%">0</span>%</h5>
                                <h6>User Feedback</h6>
                            </div>
                        </div>
                        <div class="ps-status__item">
                            <div class="ps-status__img">
                                <figure><img src="images/ps-status/img-03.png" alt="Image Description"></figure>
                            </div>
                            <div class="ps-status__title">
                                <h5><span class="count" data-count="45">0</span>,<span class="count" data-count="824"></span>,<span class="count" data-count="89"></span></h5>
                                <h6>Items Sold</h6>
                            </div>
                        </div>
                        <div class="ps-status__item">
                            <div class="ps-status__img">
                                <figure><img src="images/ps-status/img-04.png" alt="Image Description"></figure>
                            </div>
                            <div class="ps-status__title">
                                <h5><span class="count" data-count="12">0</span>,<span class="count" data-count="0"></span><span class="count" data-count="68"></span></h5>
                                <h6>Cup Of Coffee</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- STATUS END -->
        <!-- FEATURED START -->
        <section class="ps-main-section ps-featured">
            <div class="container">
                <div class="ps-center-content">
                    <div class="ps-center-description ps-featured__description">
                        <h6 class="animate" data-animate="swoopInLeft">Great People With Us</h6>
                        <h4 class="animate" data-animate="swoopInRight">Our Passionate Team</h4>
                        <p class="animate" data-animate="fadeIn">Consectetur adipisicing eliteiuim set eiusmod tempor incididunt labore etnalom dolore magna aliqua udiminimate veniam quistan norud.</p>
                    </div>
                    <div id="owl-two" class="ps-featured--cards ps-passionateTeam owl-carousel owl-theme">
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-01.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Millie Naslund<span class="d-block">Marketing Manager</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-02.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Ronny Parkison<span class="d-block">Sr. Strategy Planner</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-03.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Rocco Anderton<span class="d-block">Design Lead</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-04.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Wilfredo Taormina<span class="d-block">Troubleshoot Manager</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-01.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Millie Naslund<span class="d-block">Marketing Manager</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-02.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Ronny Parkison<span class="d-block">Sr. Strategy Planner</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-03.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Rocco Anderton<span class="d-block">Design Lead</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-04.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Wilfredo Taormina<span class="d-block">Troubleshoot Manager</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-01.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Millie Naslund<span class="d-block">Marketing Manager</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-02.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Ronny Parkison<span class="d-block">Sr. Strategy Planner</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-03.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Rocco Anderton<span class="d-block">Design Lead</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/about-page/card/img-04.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <div class="card-body">
                                    <h6>Wilfredo Taormina<span class="d-block">Troubleshoot Manager</span></h6>
                                    <ul class="ps-about-social">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
         <!-- FEATURED END -->
         <!-- FEEDBACK START -->
        <section class="ps-main-section ps-feedback">
            <div class="container">
                <div class="row">
                    <div class="col-md-11 col-lg-8 col-xl-7">
                        <div class="ps-center-content">
                            <div class="ps-center-description">
                                <h6 class="animate" data-animate="swoopInLeft">Trusted By Millions</h6>
                                <h4 class="animate" data-animate="swoopInRight">Client Feedback</h4>
                                <div class="animate" data-animate="fadeIn"><p>Consectetur adipisicing eliteiuim set eiusmod tempor incididunt labore etnalom dolore magna aliqua udiminimate veniam quistan norud.</p></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-10">
                        <div id="owl-three" class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="card">
                                    <div class="card-body">
                                        <div>
                                           <div><figure><img src="images/about-page/card-icon/img-01.jpg" alt="Image Description"></figure></div> 
                                                <h6>Lauryn Cansler<span class="d-block">Client</span></h6>
                                        </div>
                                        <p>“ Icididunt ut labore et dolore magna aliquaene
                                                ad minim veniam quistane nostrud exercitation
                                                ullamco laboris nisi ut aliquip ”</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="card">
                                    <div class="card-body">
                                        <div>
                                           <div><figure><img src="images/about-page/card-icon/img-01.jpg" alt="Image Description"></figure></div>
                                                <h6>Mikaela Spring<span class="d-block">Client</span></h6>
                                        </div>
                                        <p>“ Icididunt ut labore et dolore magna aliquaene
                                                ad minim veniam quistane nostrud exercitation
                                                ullamco laboris nisi ut aliquip ”</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="card">
                                    <div class="card-body">
                                        <div>
                                           <div><figure><img src="images/about-page/card-icon/img-01.jpg" alt="Image Description"></figure></div> 
                                                <h6>Deandre Reinert<span class="d-block">Client</span></h6>
                                        </div>
                                        <p>“ Icididunt ut labore et dolore magna aliquaene
                                                ad minim veniam quistane nostrud exercitation
                                                ullamco laboris nisi ut aliquip ”</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- FEEDBACK END -->
        <!-- BRANDS START -->
        <section class="ps-main-section ps-brands">
            <div class="container">
                <div class="row">
                    <div class="col-md-11 col-lg-8 col-xl-7">
                        <div class="ps-center-content">
                            <div class="ps-center-description">
                                <h6 class="animate" data-animate="swoopInLeft">Brands Behind Our Success</h6>
                                <h4 class="animate" data-animate="swoopInRight">Our Great Clients</h4>
                                <p class="animate" data-animate="fadeIn">Consectetur adipisicing eliteiuim set eiusmod tempor incididunt labore etnalom dolore magna aliqua udiminimate veniam quistan norud.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ps-brands-img">
                    <figure><img src="images/about-page/brands/img-01.png" alt="Image Description"></figure>
                    <figure><img src="images/about-page/brands/img-02.png" alt="Image Description"></figure>
                    <figure><img src="images/about-page/brands/img-03.png" alt="Image Description"></figure>
                    <figure><img src="images/about-page/brands/img-04.png" alt="Image Description"></figure>
                    <figure><img src="images/about-page/brands/img-05.png" alt="Image Description"></figure>
                </div>
            </div>
        </section>
         <!-- BRANDS END -->
    </main>
    <!-- MAIN END -->
    <?php include("includes/footer.php");?>
</body>
</html>