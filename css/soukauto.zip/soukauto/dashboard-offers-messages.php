<!DOCTYPE html>
<html lang="fr">
<?php include("includes/header.php");?>
<body>
    <?php include("includes/menu.php");?>
    <!-- MAIN START -->
    <main class="ps-main">
        <section class="ps-main-section">
            <div class="container">
                <div class="row">
                    <!-- SIDEBAR START -->
                    <div class="col-lg-4">
                        <div class="ps-dashboard-sidebar">
                            <div class="ps-dashboard-sidebar__user">
                                <figure><img src="images/insights/user-img.jpg" alt="Image Description"></figure>
                                <div class="ps-seller__description">
                                    <h6>Lorina Statham</h6>
                                    <div class="ps-h5">Status: 
                                        <a data-toggle="collapse" href="#collapseUser" role="button" aria-expanded="false">
                                            <span><em class="ps-online"></em><i class="fa fa-sort-down"></i></span><em>Online</em> 
                                        </a>
                                        <div class="collapse" id="collapseUser">
                                            <a href="javascript:void(0);"><span class="ps-online"></span><em>Online</em></a>
                                            <a href="javascript:void(0);"><span class="ps-away"></span><em>Away</em></a>
                                            <a href="javascript:void(0);"><span class="ps-busy"></span><em>Busy</em></a>
                                            <a href="javascript:void(0);"><span class="ps-offline"></span><em>Offline</em></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="ps-dashboard-sidebar__edit"><a href="javascript:void(0);"><i class="ti-pencil"></i></a></div>
                            </div>
                            <ul>
                                <li><a href="dashboard-insights.php"><i class="ti-dashboard"></i> <span>Insights</span> </a></li>
                                <li><a href="dashboard-profile-setting.php"><i class="ti-user"></i> <span>Profile Settings</span> </a></li>
                                <li><a href="dashboard-my-ads.php"><i class="ti-align-justify"></i> <span>My Ads</span> </a></li>
                                <li><a href="dashboard-post-ad.php"><i class="ti-settings"></i> <span>Post Ad</span> </a></li>
                                <li><a href="dashboard-offers-messages.php" class="ps-user-dhb"><i class="ti-email"></i> <span>Offers/messages</span> </a></li>
                                <li><a href="dashboard-buy-package.php" class="ps-active--line"><i class="ti-shopping-cart"></i> <span>Buy New Packages</span> </a></li>
                                <li><a href="dashboard-payments.php"><i class="ti-user"></i> <span>Payments</span> </a></li>
                                <li>
                                    <a data-toggle="collapse" href="#collapsenew" role="button" aria-expanded="false"><i class="ti-heart"></i> <span>My Favorite</span> <span class="ps-right"><i class="ti-angle-right"></i></span> </a>
                                    <ul class="collapse" id="collapsenew">
                                        <li><a href="dashboard-my-favorite.php"><span>Favorite Listing</span></a></li>
                                        <li><a href="javascript:void(0);"><span>Sub Menu</span></a></li>
                                    </ul>
                                </li>
                                <li><a href="dashboard-account-setting.php"><i class="ti-bookmark"></i> <span>Account & Privacy Settings</span> </a></li>
                                <li><a href="index-2.php"><i class="ti-shift-right"></i> <span>Logout</span> </a></li>
                            </ul>
                        </div>
                        <div class="ps-gridList__ad ps-dashboard-img">
                            <a href="javascript:void(0);"><figure><img src="images/ad-img.jpg" alt="Image Description"></figure></a>
                            <span>Advertisement  255px X 255px</span>
                        </div>
                    </div>
                    <!-- SIDEBAR END -->
                    <!-- MAIN CONTENT START -->
                    <div class="col-lg-8 ps-dashboard-user">
                        <div class="ps-posted-ads ps-messages">
                            <div class="ps-posted-ads__heading">
                                <h5>Offers/Messages</h5>
                            </div>
                            <div class="ps-messages__description">
                                <p>Select Your Product to See Their Messages:</p>
                                <div class="ps-user-product">
                                    <a class="ps-product-collapse" data-toggle="collapse" href="#collapsenew1" role="button" aria-expanded="false">
                                        <img src="images/messages/icon/img-01.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Smart Wrist Watch Pro, Slightly Used</span>
                                            <em>$690</em>
                                        </span>
                                        <i class="ti-angle-down"></i>
                                    </a>
                                    <div class="ps-profile-setting__imgs ps-message-product collapse" id="collapsenew1">
                                        <div class="ps-y-axis mCustomScrollbar">
                                            <input type="radio" name="product-input" id="product1">
                                            <label class="ps-product-dot">
                                                <img src="images/messages/icon/img-02.jpg" alt="Image Description">
                                                <span class="ps-messages__text">
                                                    <span>Brand New Iphone X For Sale</span>
                                                    <em>$1,149</em>
                                                </span>
                                            </label>
                                            <input type="radio" name="product-input" id="product2">
                                            <label class="ps-product-dot">
                                                <img src="images/messages/icon/img-01.jpg" alt="Image Description">
                                                <span class="ps-messages__text">
                                                    <span>Smart Wrist Watch Pro, Slightly Used</span>
                                                    <em>$690</em>
                                                </span>                                            
                                            </label>
                                            <input type="radio" name="product-input" id="product3">
                                            <label>
                                                <img src="images/messages/icon/img-03.jpg" alt="Image Description">
                                                <span class="ps-messages__text">
                                                    <span>Brand New Touch Book For Sale</span>
                                                    <em>$1,320</em>
                                                </span>
                                            </label>
                                            <input type="radio" name="product-input" id="product4">
                                            <label>
                                                <img src="images/messages/icon/img-04.jpg" alt="Image Description">
                                                <span class="ps-messages__text">
                                                    <span>Smart Wrist Watch Pro, Slightly Used</span>
                                                    <em>$690</em>
                                                </span>
                                            </label>
                                            <input type="radio" name="product-input" id="product5">
                                            <label>
                                                <img src="images/messages/icon/img-05.jpg" alt="Image Description">
                                                <span class="ps-messages__text">
                                                    <span>100% working drone for sale/exchange</span>
                                                    <em>$1,458</em>
                                                </span>
                                            </label>
                                            <input type="radio" name="product-input" id="product6">
                                            <label>
                                                <img src="images/messages/icon/img-05.jpg" alt="Image Description">
                                                <span class="ps-messages__text">
                                                    <span>100% working drone for sale/exchange</span>
                                                    <em>$1,458</em>
                                                </span>
                                            </label>
                                            <input type="radio" name="product-input" id="product7">
                                            <label>
                                                <img src="images/messages/icon/img-05.jpg" alt="Image Description">
                                                <span class="ps-messages__text">
                                                    <span>100% working drone for sale/exchange</span>
                                                    <em>$1,458</em>
                                                </span>
                                            </label>
                                        </div>                                   
                                    </div>
                                </div>
                            </div>
                            <div class="ps-messages__content">
                                <!-- USER AREA START -->
                                <ul class="ps-y-axis mCustomScrollbar">
                                    <li>
                                        <a href="javascript:void(0);" class="ps-dot">
                                        <img src="images/user-icon/img-06.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Jacquelyn Hagemeier</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="ps-dot">
                                        <img src="images/user-icon/img-01.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Otelia Izquierdo</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="ps-dot">
                                        <img src="images/user-icon/img-12.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Abdul Winsett</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                        <img src="images/user-icon/img-09.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Amee Kinkead</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                        <img src="images/user-icon/img-04.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Lyle Ruybal</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                        <img src="images/user-icon/img-13.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Gordon Prow</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                        <img src="images/user-icon/img-08.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Selina Charlebois</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                        <img src="images/user-icon/img-14.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Selina Charlebois</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                        <img src="images/user-icon/img-14.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Selina Charlebois</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                        <img src="images/user-icon/img-14.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Selina Charlebois</span>
                                            <em>Jun 27, 2019</em>
                                        </span>
                                        </a>
                                    </li>
                                </ul>
                                <!-- USER AREA END -->
                                <div class="ps-messages__user">
                                    <div class="ps-messages__user__heading">
                                        <a href="javascript:void(0);"><i class="ti-arrow-left"></i></a>
                                        <img src="images/user-icon/img-09.jpg" alt="Image Description">
                                        <span class="ps-messages__text">
                                            <span>Amee Kinkead</span>
                                            <em>Last Online: Aug 08, 2019</em>
                                        </span>
                                        <a href="javascript:void(0);"><i class="ti-trash"></i></a> 
                                    </div>
                                    <!-- MESSAGE AREA START -->
                                    <div class="ps-messages__area ps-y-axis mCustomScrollbar">
                                        <div class="ps-messages__area__right">
                                            <p>Nostrud exercitation ullam aeco laboris nisi utae commodo consequat duis aute.</p>
                                            <p>Nostrud exercitation ullam aeco laboris nisi utae commodo consequat duis aute.</p>
                                            <p>Nostrud exercitation ullam aeco laboris nisi utae commodo consequat duis aute.</p>
                                            <p>https://themeforest.net/</p>
                                            <p>It that ok?</p>
                                            <p>Ullam aeco laboris nisi utaeisea commodo</p>
                                            <span>Jun 28, 2019 09:30 <i class="fas fa-check"></i></span>
                                        </div>
                                        <div class="ps-messages__area__left">
                                            <p>Consectetur adipisicing elied diod taempor incint labore dolore ainare Ut enim ad minim veni ame quis nostrud exercitation ullamco laboris.</p>
                                            <p>Consectetur adipisicing elied diod taempor incint labore dolore ainare Ut enim ad minim veni ame quis nostrud exercitation ullamco laboris.</p>
                                            <p>Consectetur adipisicing elied diod taempor incint labore dolore ainare Ut enim ad minim veni ame quis nostrud exercitation ullamco laboris.</p>
                                            <span>Jun 27,2019 14:11</span>
                                        </div>
                                    </div>
                                    <div class="ps-text__area">
                                        <textarea class="form-control" placeholder="Type Message Here"></textarea>
                                        <div class="ps-emoji">
                                            <a href="javascript:void(0);">
                                                <img src="images/messages/img-01.png" alt="Image Description">
                                                <span><i class="fas fa-angle-right"></i></span>
                                            </a>
                                            <button class="btn ps-btn">Send</button>
                                        </div>
                                    </div>
                                    <!-- MESSAGE AREA END -->
                                </div>
                            </div>
                            <div class="ps-no-ads">
                                <div>
                                    <figure><img src="images/messages/img-02.png" alt="Image Description"></figure>
                                    <h5>No Offer/Messages Found :(</h5>
                                    <h6>Click “Post Ad” button below to post your free ad</h6>
                                    <button class="btn ps-btn">Post Ad</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- MAIN CONTENT END -->
                </div>
            </div>
        </section>
    </main>
    <!-- MAIN END -->
    <?php include("includes/footer.php");?>

</body>
</html>