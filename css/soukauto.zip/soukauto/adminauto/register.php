<?php 
session_start();
include("../librairie/x25.php");
$sql="SELECT * FROM users WHERE login='".$_SESSION['adminprestige']."' && activ=1";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);

if(empty($_SESSION['adminprestige']) || empty($row['login']))
	header("Location:index.php");	

?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8"/>
	<title>Adminsitration Souk Auto</title>
	
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="screen" />
	<!--[if lt IE 9]>
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen" />
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<script src="js/jquery-1.5.2.min.js" type="text/javascript"></script>
	<script src="js/hideshow.js" type="text/javascript"></script>
	<script src="js/jquery.tablesorter.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/jquery.equalHeight.js"></script>
	<script type="text/javascript">
	$(document).ready(function() 
    	{ 
      	  $(".tablesorter").tablesorter(); 
   	 } 
	);
	$(document).ready(function() {

	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content

	//On Click Event
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});

});
    </script>
    <script type="text/javascript">
    $(function(){
        $('.column').equalHeight();
    });
</script>

</head>


<body>
    <?php include("menu.php");?>
		<section id="main" class="column">
        <h4 class="alert_info">Bienvenu à l'administration de Souk Auto.</h4>

    <?php
		if(isset($_POST['submit']))
		{
			if(empty($_POST['nom']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ nom est obligatoire</h4>';
			}
		  	if(empty($_POST['prenom']))
			{
				
				echo '<h4 class="alert_error" style="float:left;">Champ prenom est obligatoire</h4>';
			}
			if(empty($_POST['email']))
			{
				
				echo '<h4 class="alert_error" style="float:left;">Champ email est obligatoire</h4>';
			}
		  	if(empty($_POST['login']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ login est obligatoire</h4>';
			}
			if(empty($_POST['motdepasse']) || strlen($_POST['motdepasse'])<4)
			{
				echo '<h4 class="alert_error" style="float:left;">Champ Mot de passe est obligatoire, et supérieur à 4</h4>';
			}
			
							/*text existance login et email*/
				$sql="SELECT * FROM users WHERE login='".$_POST['login']."' || email='".$_POST['email']."'";
				$result=mysql_query($sql);
				$row=mysql_fetch_array($result);
				if($row['login']==$_POST['login'])
				{
				$exist=1;	
				echo '<h4 class="alert_error" style="float:left;">Login existant, merci de choisir autre.</h4>';
				}
				else if($row['email']==$_POST['email'])
				{
					$exist=1;
					echo '<h4 class="alert_error" style="float:left;">Email existant, merci de choisir autre login.</h4>';
				}
				else
				{
					$exist=0;	
				}
				if($exist==0 && !empty($_POST['nom']) && !empty($_POST['prenom'])&& !empty($_POST['email']) && !empty($_POST['login']) && !empty($_POST['motdepasse']) && strlen($_POST['motdepasse'])>4)
				{
											
						$qid2 = mysql_query("insert into users (nom,prenom,email,login,motpasse,motdepasse,statut) values ('".$_POST['nom']."','".$_POST['prenom']."','".$_POST['email']."','".$_POST['login']."','".md5($_POST['motdepasse'])."','".$_POST['motdepasse']."','admin')")or DIE('<div class="error">Probl&egrave;me dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
					echo '<h4 class="alert_success">Insertion Information effectuées avec succés</h4>';
					session_destroy();
					$_SESSION['adminprestige']='';
					$from  = "From:contact@soukauto.tn\n";
					$from .= "MIME-version: 1.0\n";
					$from .= "Content-type: text/html; charset= iso-8859-1\n";
										
					$subj="Activation compte admin souk auto".$_POST['nom']." ".$_POST['prenom'];
					mail('contact@soukauto.tn',$subj,"Bonjour, <a href='http://www.soukauto.tn/adminauto/activ.php?m=".$_POST['email']."'>cliquer ici pour activer compte admin souk auto :".$_POST['nom']." ".$_POST['prenom']."</a>",$from);
					mail('razouae@gmail.com',$subj,"Bonjour, <a href='http://www.soukauto.tn/adminauto/activ.php?m=".$_POST['email']."'>cliquer ici pour activer compte admin souk auto :".$_POST['nom']." ".$_POST['prenom']."</a>",$from);
					?>
					<script>setTimeout(function(){location.replace("index.php");},4000);</script>
					<?php
				}			
		}
	?>
	
    <!-- end of sidebar -->
    <form name="profil" method="post" action="">
		
				<article class="module width_full">
			<header><h3>Ajouter un Compte</h3></header>
				<div class="module_content">
						<fieldset>
                                    <label>Nom :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['nom'] : '' ?>" name="nom">
                                         
                                    <label>Prenom :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['prenom'] : '' ?>" name="prenom">
                                     <label>Email :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['email'] : '' ?>" name="email">
                                     <label>Login :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['login'] : '' ?>" name="login">
                                    <label>Mot de passe : </label>
                                    <input type="password" value="<?php echo (isset($_POST['submit'])) ? $_POST['motdepasse'] : '' ?>" name="motdepasse">
                                   
                        </fieldset>
				</div>
			<footer>
                        <div class="submit_link">
                            <input name="submit" type="submit" value="Valider" class="alt_btn">
                            <input name="reset" type="reset" value="Effacer">
                        </div>
			</footer>
            
		</article>
         </form>
<!-- end of styles article -->
		<div class="spacer"></div>
	</section>


</body>
</html>