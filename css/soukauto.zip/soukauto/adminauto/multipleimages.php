<?php 
session_start();
include("../librairie/x25.php");
$sql="SELECT * FROM users WHERE login='".$_SESSION['adminprestige']."' && activ=1";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);

if(empty($_SESSION['adminprestige']) || empty($row['login']))
	header("Location:index.php");	

?>
<!doctype html>
<html lang="fr">
<head>
	<meta charset="utf-8"/>
	<title>Adminsitration Immobiliere le prestige</title>
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="screen" />
	<!--[if lt IE 9]>
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen" />
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<script src="js/jquery-1.5.2.min.js" type="text/javascript"></script>
	<script src="js/hideshow.js" type="text/javascript"></script>
	<script src="js/jquery.tablesorter.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/jquery.equalHeight.js"></script>
	<script type="text/javascript">
	$(document).ready(function() 
    	{ 
      	  $(".tablesorter").tablesorter(); 
   	 } 
	);
	$(document).ready(function() {

	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content

	//On Click Event
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});

});
</script>
<script type="text/javascript">
    $(function(){
        $('.column').equalHeight();
    });
</script>
</head>
<body>
		<?php include("menu.php");?>
    <!-- end of sidebar -->
	<script language="javascript">
		function activbloc()
		{
			if(document.getElementById("typebilanautre").style.display=='none' && document.getElementById("typebilan").value=="autre")
			{
				document.getElementById("typebilanautre").style.display='block';
				document.getElementById("typebilanautre").style.visibility='visible';
				
				document.getElementById("titlebil").style.display='block';
				document.getElementById("titlebil").style.visibility='visible';

			}
			else
			{
				document.getElementById("typebilanautre").style.display='none';
				document.getElementById("typebilanautre").style.visibility='hidden';
				
				document.getElementById("titlebil").style.display='none';
				document.getElementById("titlebil").style.visibility='hidden';

			}			
	}
	function activcont()
	{
			if(document.getElementById("typecontautre").style.display=='none' && document.getElementById("typecontrat").value=="autre")
			{
				document.getElementById("typecontautre").style.display='block';
				document.getElementById("typecontautre").style.visibility='visible';
				
				document.getElementById("titlecont").style.display='block';
				document.getElementById("titlecont").style.visibility='visible';

			}
			else
			{
				document.getElementById("typecontautre").style.display='none';
				document.getElementById("typecontautre").style.visibility='hidden';
				
				document.getElementById("titlecont").style.display='none';
				document.getElementById("titlecont").style.visibility='hidden';

			}		
	}
	</script>
	<section id="main" class="column">
		<h4 class="alert_info">Bienvenu</h4>
        <?php
		$mode=$_GET['mode'];
		if($mode=='supprimer')
		{
			
			/*delete produit*/
			mysql_query("Delete From image where id_image=".$_GET['id']);
			echo '<h4 class="alert_success">Suppression effectu&eacute; avec succ&eacute;s</h4><br/>';
			?><script>setTimeout(function(){location.replace("multipleimages.php");},1500);</script><?php
		}
		if($mode=='supp')
		{
			?>
            <script language=javascript>
            <!--
                var result = confirm("Etes vous certain de supprimer cette text?"); 
                if(result)
                {
					location.replace("multipleimages.php?mode=supprimer&id="+<?php echo $_GET['i'] ?>);
                }
                else 
				{
                    location.replace("multipleimages.php");
                }
            --> 
            </script>
            <?php
		}
		else
		{
		?>
		<article class="module width_3_quarter">
		<header>
		  <h3 class="tabs_involved">Tableau liste image par produit</h3></header>
	      <div class="tab_container">
			<div id="tab1" class="tab_content">
<?php
include("../librairie/x25.php");

include("classes/upload_image.class.php");
$categorie = new categorie();
switch ($_REQUEST['mode']) 
{ 

	case "ajout" :
		$categorie->affiche_formulaire_ajout_categorie();

	break;
	case "modif" :

		$categorie->affiche_formulaire_modif_categorie($_REQUEST['id']); 
	break;
	case "supp" :
	
		$categorie->supprime_categorie($_REQUEST['id']);
$categorie->affiche_liste_categorie(); 
	break;
	case "inserer" :

            $categorie->inserer_categorie($HTTP_POST_VARS);
		$categorie->affiche_liste_categorie(); 

	break;
	case "maj" :
		
		$categorie->maj_categorie($HTTP_POST_VARS,$_REQUEST['id']);
		
	break;
	case "supp_fichier" :
		
		$categorie->supprime_image($_REQUEST['id']);
		$categorie->affiche_formulaire_modif_categorie($_REQUEST['id']);
$categorie->affiche_liste_categorie(); 
	break;
	case "recherche" :
		$categorie->affiche_liste_categorie_recherche($HTTP_POST_VARS,2);
	break;
	case "clearall":
		$categorie->cleartable();
	break;
	case "clearok":
		$categorie->okclear();
	break;
	default :
		$categorie->affiche_liste_categorie(); 
	break;

}

?>			</div><!-- end of #tab1 -->			
		</div><!-- end of .tab_container -->		
		</article><!-- end of content manager article -->
		<?php }?>
        <!-- end of messages article -->
		<div class="clear"></div>
		<!-- end of styles article -->
		<div class="spacer"></div>
	</section>
</body>
</html>