<?php session_start();
//Connect to database from here
include("../librairie/x25.php");

//get the posted values
$user_name=htmlspecialchars($_POST['user_name'],ENT_QUOTES);
$pass=md5($_POST['password']);

//now validating the username and password
$sql="SELECT * FROM users WHERE login='".$user_name."' && motpasse='".$pass."'";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);

//if username exists
if(mysql_num_rows($result)>0)
{
	//compare the password
	if((strcmp($row['motpasse'],$pass)==0))
	{
		if($row['activ']=='1')
		{
			echo "yes";
		//now set the session from here if needed
		$_SESSION['adminprestige']=$row["login"];
		$_SESSION["statut"]=$row["statut"];
		}
		else
		{
			echo 'ko';
		}
	}
	else
	{
		echo "no"; 
	}
}

?>