<?php
session_start();
include("../librairie/x25.php");
$sql="SELECT * FROM users WHERE login='".$_SESSION['adminprestige']."' && activ=1";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);
if(!empty($_SESSION['adminprestige']) || !empty($row['login']))
	header("Location:acceuil.php");	
?>
<!DOCTYPE html>
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8" />
  <!-- Set the viewport width to device width for mobile -->
  <meta name="viewport" content="width=device-width" />
  <title>Adminsitration Immobiliere le prestige</title>
  <!-- Included Bootstrap CSS Files -->
	<link rel="stylesheet" href="js/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="js/bootstrap/css/bootstrap-responsive.min.css" />
	<!-- Includes FontAwesome -->
	<link rel="stylesheet" href="css/fontawesome/css/font-awesome.css" />
	<!-- Included Bootstrap Customization CSS Files -->	
	<link rel="stylesheet" href="css/bootstrap-extension.css" />
	<link rel="stylesheet" href="css/carousel-custom-01.css" />
	<link rel="stylesheet" href="css/stylesheet.css" />
    <link rel="stylesheet" href="css/msgbox.css" />
	<link rel="stylesheet" href="css/login.css" />
	<script src="js/jquery.js" type="text/javascript" language="javascript"></script>
</head>
<body>
  <div class="navbar navbar-fixed-top">
    <div class="navbar-inner">
      <div class="container">
        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse" href="#">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </a>
        <a class="brand" href="#" title="">Admin immobiliére le prestige</a>
      </div>
    </div>
  </div>
  <div class="container">
        <div id="login-wraper">
        <?php
							if(isset($_POST['Submit']))
							{
								$TO=$_POST['mail'];
								$sql2="SELECT * FROM users where login='".$_POST['username']."' && email='".$_POST['mail']."' && activ=1";
								$result2=mysql_query($sql2);
								$row2=mysql_fetch_array($result2);

								if($row2['email']==$TO)
								{
									$existe=1;
								}
								else
								{
									$existe=2;
								}
								$regex_mail = '/^[-+.\w]{1,64}@[-.\w]{1,64}\.[-.\w]{2,6}$/i';
								if(!empty($_POST['username']) && !empty($_POST['mail']) && preg_match($regex_mail, $TO) && $existe==1)
								{
								
								$message_final='Bonjour,<br/><br/><table width="100%" height="120" border="0">
								  <tr>
									<td width="33%" height="35">Login :</td>
									<td width="88%">'.$_POST['username'].'</td>
								  </tr>
								  <tr>
									<td width="33%" height="35">Votre Nouvelle Mot de passe :</td>
									<td width="88%">'.$_POST['username'].'</td>
								  </tr>
								  <tr>
									<td height="35" colpsan="2">NB: Il est obligatoirement de modifier votre mot de passe au prochaine connexion à l\'interface admin pour sécurisé vos données.</td>
								  </tr>
								  <tr>
									<td height="35">Email :</td>
									<td>'.$_POST['mail'].'</td>
								  </tr>
								</table><br/><br/><br/>Immobiliere le prestige';				
									
								//$TO='contact@help-children-learn.org';	
								//$TO='razouane@gmail.com';
								$from  = "From:contact@immobiliere-le-prestige.com\n";
				
								$from .= "MIME-version: 1.0\n";
				
								$from .= "Content-type: text/html; charset= iso-8859-1\n";
				
								$subject='Récupération de mot de passe';	
						
								mail($TO,$subject,$message_final,$from);
				
								$envoyer = 1;
								$qid2 = mysql_query('update users set motpasse="'.md5($_POST['username']).'", motdepasse="'.$_POST['username'].'" where login="'.$_POST['username'].'" && email="'.$_POST['mail'].'"')or DIE('<div class="error">Probl&egrave;me dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
								echo "<div class='alert_success'>Votre Mot de passe a &eacute;t&eacute; r&eacute;cup&eacute;r&eacute;e avec succ&eacute;s.</div>";
 								}
								else
								{
									echo "<div class='alert_warning'>Champ vide , email incorrect ou bien faux login .</div>";
								}
								
							}
						?>
            <form class="form login-form" name="login" id="login_form" action="" method="post">
                <legend>Récupérer  Mot de passe</legend>
                <div class="body">
                    <label>Nom d'utilisateur</label>
                    <input type="text" name="username" id="username" value="">
                    
                    <label> Email d'inscription</label>
                    <input type="text" name="mail" id="mail" value="">
                </div>
                <div class="footer">                              
                  <button type="submit" class="btn btn-success" name="Submit" id="submit">Connexion</button>
                </div>
                <div class="footer">
					<span id="msgbox" style="display:none; font-size:11px;"></span>
				</div>
            </form>
        </div>
    </div>
   <footer class="white navbar-fixed-bottom">
		Powered By <a href="http://www.fayasolutions.com" target="_blank" class="btn btn-black">Fayasolutions</a> <a href="index.php" style="float:right;" class="btn btn-black">allez au Connexion</a>
   </footer>
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/holder.js"></script>
	<script src="js/backstretch.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$.backstretch([
		      "img/bg1.png",
			  "img/image_6.jpg",
			  "img/image_2.jpg",
			  "img/IMGP9360mf.jpg",
			  "img/image_5.jpg",
		      "img/bg2.png"
		  	], {duration: 3000, fade: 750});
		});
	</script>
</body>
</html>