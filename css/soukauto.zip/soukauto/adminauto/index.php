<?php
session_start();
include("../librairie/x25.php");
$sql="SELECT * FROM users WHERE login='".$_SESSION['adminprestige']."' && activ=1";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);

if(!empty($_SESSION['adminprestige']) || !empty($row['login']))
	header("Location:acceuil.php");	
?>
<!DOCTYPE html>
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8" />

  <!-- Set the viewport width to device width for mobile -->
  <meta name="viewport" content="width=device-width" />

  <title>Adminsitration Souk Auto</title>

  <!-- Included Bootstrap CSS Files -->
	<link rel="stylesheet" href="js/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="js/bootstrap/css/bootstrap-responsive.min.css" />
	
	<!-- Includes FontAwesome -->
	<link rel="stylesheet" href="css/fontawesome/css/font-awesome.css" />
	
	<!-- Included Bootstrap Customization CSS Files -->	
	<link rel="stylesheet" href="css/bootstrap-extension.css" />
	<link rel="stylesheet" href="css/carousel-custom-01.css" />

	<link rel="stylesheet" href="css/stylesheet.css" />
    <link rel="stylesheet" href="css/msgbox.css" />
	<link rel="stylesheet" href="css/login.css" />

	<script src="js/jquery.js" type="text/javascript" language="javascript"></script>
	<script src="js/msgbox-login.js" type="text/javascript" language="javascript"></script>

</head>
<body>
  <div class="navbar navbar-fixed-top">
    <div class="navbar-inner">
      <div class="container">
        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse" href="#">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </a>
        <a class="brand" href="#" title="Actif assur">Admin Souk Auto</a>

      </div>
    </div>
  </div>

    <div class="container">
        <div id="login-wraper">
        <?php
		
		?>
            <form class="form login-form" name="login" id="login_form" action="" method="post">
                <legend>Connexion</legend>
                <div class="body">
                    <label>Nom d'utilisateur</label>
                    <input type="text" name="username" id="username" value="">
                    
                    <label>Mot de passe</label>
                    <input type="password" name="password" id="password" value="">
                </div>
                <div class="footer">
                    <label class="checkbox inline">
                        <input type="checkbox" id="inlineCheckbox1" value="souvenir"> Se souvenir de moi
                    </label>
                                
                     <button type="submit" class="btn btn-success" name="Submit" id="submit">Connexion</button><br/>
                        <a class="checkbox inline" href="motdepasseoublier.php">Changer Mot de passe oublié =></a>
                </div>
                <div class="footer">
					<span id="msgbox" style="display:none; font-size:11px;"></span>
				</div>
            </form>
        </div>

    </div>

   <footer class="white navbar-fixed-bottom">
		Powered By <a href="http://www.fayasolutions.tn" target="_blank" class="btn btn-black">Fayasolutions</a>
   </footer>
	<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/holder.js"></script>
	<script src="js/backstretch.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function() {

			$.backstretch([
		      "img/bg1.png",
			  "img/image_6.jpg",
			  "img/image_2.jpg",
			  "img/IMGP9360mf.jpg",
			  "img/image_5.jpg",
		      "img/bg2.png"
		  	], {duration: 3000, fade: 750});

		});
	</script>
</body>
</html>