<?php

class categorie

{


	function affiche_formulaire_categorie($flag) 
	{
		


		GLOBAL $frm,$options;
?>

<div id="container">

  <div id="Layer1">
	<?php
    
    if(isset($_POST['subimage']))
	{
		
		if(!empty($_FILES['files']['name']) && (!empty($_POST['id_cat']) || !empty($_POST['id_desci'])))
			{
				
			$errors= array();
			foreach($_FILES['files']['tmp_name'] as $key => $tmp_name )
			{
				$file_name = $key.$_FILES['files']['name'][$key];
				$file_size =$_FILES['files']['size'][$key];
				$file_tmp =$_FILES['files']['tmp_name'][$key];
				$file_type=$_FILES['files']['type'][$key];	
				if($file_size > 120097152)
				{
					$errors[]='File size must be less than 2 MB';
				}		
				
				$qimg3=$file_name;
	
				if($qimg3==".png")
	
				{
	
				$extension='.png';
	
				}
	
				elseif($qimg3==".gif")
	
				{
	
				$extension='.gif';
	
				}
	
				elseif($qimg3==".bmp")
	
				{
	
				$extension='.bmp';
	
				}
	
				elseif($qimg3==".jpg" || $qimg3==".JPG" || $qimg3==".JPEG" ||  $qimg3==".jpeg")
				{
	
				$extension='.jpg';
	
				}
				else
				{
				$extension='.jpg';
				}
				
	
				$newname=rand();
	
				$qimgnew3=$newname.$extension;
				
				if(!empty($_POST['id_cat']))
				{
					$id=$_POST['id_cat'];
					$type='categorie';
				}
				if(!empty($_POST['id_desci']))
				{
					$id=$_POST['id_desci'];
					$type='produit';
				}
				
		
				$qid = mysql_query("insert into image (id_rubrique,nom_image,type) values ('".$id."','".$qimgnew3."','".$type."')") or die('<div class="error">Probl&egrave;me d\'insertion de images dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
			
			//$desired_dir="user_data";
			$desired_dir=PATH_IMAGE;
			if(empty($errors)==true)
			{
				if(is_dir($desired_dir)==false)
				{
					mkdir("$desired_dir", 0700);		// Create directory if it does not exist
				}
				if(is_dir("$desired_dir/".$qimgnew3)==false)
				{
					move_uploaded_file($file_tmp,"$desired_dir/".$qimgnew3);
				}
				else
				{									// rename the file if another one exist
					$new_dir="$desired_dir/".$qimgnew3.time();
					 rename($file_tmp,$new_dir) ;				
				}
			 mysql_query($query);			
			}
			else
			{
					print_r($errors);
			}
			
			if(empty($error))
			{
				//echo "Success";
				if ($qid) 
				{
		
					echo "<h4 class='alert_success'>Insertion effectu&eacute;e avec succ&egrave;s</h4>";
					
				}
				else
				{
					echo "<h4 class='alert_success'>Probléme chargement donn&eacute;es</h4>";
				}
			}
			else
			{
					echo "<h4 class='alert_success'>Probléme chargement donn&eacute;es</h4>";
			
			}
		  }
			
		}
			
	}
?>
   <form name="form1" method="POST"  action="" enctype="multipart/form-data">
      <input type="hidden" name="mode" value="<?php echo $frm["nouveau_mode"]?>" />

    <table border="0" width="100%" cellpadding="0" cellspacing="1">
		
        <tr>

            <td width="276">List Catégorie :</td>

            <td width="763">

                <?php  $sqlfanfftourisme="SELECT * FROM categorie order by id_categorie DESC";

                $resultfanfftourisme=mysql_query($sqlfanfftourisme);

                while($rowfanfftourisme=mysql_fetch_array($resultfanfftourisme))

                {

                    if(str_replace(' ','_',$rowfanfftourisme['id_categorie'])==$frm['id_categorie'])

                    {$selectfftourisme=' selected="selected"';}

                    $urlffcat='<option value="'.str_replace(' ','_',$rowfanfftourisme['id_categorie']).'" '.$selectfftourisme.'>'.$rowfanfftourisme['nom_categorie'].'</option>'.$urlffcat;

                }

           ?>

            <select name="id_cat">

              <option value="">------</option><?php echo $urlffcat?></select>                

            </td>

         </tr>
        <tr>

            <td width="276">List Produit :</td>

            <td width="763">

                <?php  $sqlfanff="SELECT * FROM produit order by id_desci DESC";

                $resultfanff=mysql_query($sqlfanff);

                while($rowfanff=mysql_fetch_array($resultfanff))

                {

                    if(str_replace(' ','_',$rowfanff['id_desci'])==$frm['id_desci'])

                    {$selectff=' selected="selected"';}

                    $urlff='<option value="'.str_replace(' ','_',$rowfanff['id_desci']).'" '.$selectff.'>'.$rowfanff['nomproduit'].'</option>'.$urlff;

                }

           ?>

            <select name="id_desci">

              <option value="">------</option><?php echo $urlff?></select>                

            </td>

         </tr>
         <tr>

            <td width="276">List Catégorie projet en cours:</td>

            <td width="763">

                <?php  $sqlfanfftourismepc="SELECT * FROM categorie_projet_encour order by id_categorie DESC";

                $resultfanfftourismepc=mysql_query($sqlfanfftourismepc);

                while($rowfanfftourismepc=mysql_fetch_array($resultfanfftourismepc))

                {

                    if(str_replace(' ','_',$rowfanfftourismepc['id_categorie'])==$frmpc['id_categorie'])

                    {$selectfftourismepc=' selected="selected"';}

                    $urlffcatpc='<option value="'.str_replace(' ','_',$rowfanfftourismepc['id_categorie']).'" '.$selectfftourismepc.'>'.$rowfanfftourismepc['nom_categorie'].'</option>'.$urlffcatpc;

                }

           ?>

            <select name="id_cat_pc">

              <option value="">------</option><?php echo $urlffcatpc?></select>                

            </td>

         </tr>
        <tr>

            <td width="276">List Produit projet en cours:</td>

            <td width="763">

                <?php  $sqlfanffpc="SELECT * FROM produit_projet_encour order by id_desci DESC";

                $resultfanffpc=mysql_query($sqlfanffpc);

                while($rowfanffpc=mysql_fetch_array($resultfanffpc))
                {

                    if(str_replace(' ','_',$rowfanffpc['id_desci'])==$frmpc['id_desci'])

                    {$selectffpc=' selected="selected"';}

                    $urlffpc='<option value="'.str_replace(' ','_',$rowfanffpc['id_desci']).'" '.$selectffpc.'>'.$rowfanffpc['nomproduit'].'</option>'.$urlffpc;

                }

           ?>

            <select name="id_desci_pc">

              <option value="">------</option><?php echo $urlffpc?></select>                

            </td>

         </tr>
         
          <tr>

            <td width="276">List Catégorie projet realise:</td>

            <td width="763">

                <?php  $sqlfanfftourismepr="SELECT * FROM categorie_projet_realise order by id_categorie DESC";

                $resultfanfftourismepr=mysql_query($sqlfanfftourismepr);

                while($rowfanfftourismepr=mysql_fetch_array($resultfanfftourismepr))

                {

                    if(str_replace(' ','_',$rowfanfftourismepr['id_categorie'])==$frmpr['id_categorie'])

                    {$selectfftourismepr=' selected="selected"';}

                    $urlffcatpr='<option value="'.str_replace(' ','_',$rowfanfftourismepr['id_categorie']).'" '.$selectfftourismepr.'>'.$rowfanfftourismepr['nom_categorie'].'</option>'.$urlffcatpr;

                }

           ?>

            <select name="id_cat_pr">

              <option value="">------</option><?php echo $urlffcatpr?></select>                

            </td>

         </tr>
        <tr>

            <td width="276">List Produit projet realise:</td>

            <td width="763">

                <?php  $sqlfanffpr="SELECT * FROM produit_projet_realise order by id_desci DESC";

                $resultfanffpr=mysql_query($sqlfanffpr);

                while($rowfanffpr=mysql_fetch_array($resultfanffpr))
                {

                    if(str_replace(' ','_',$rowfanffpr['id_desci'])==$frmpr['id_desci'])

                    {$selectffpr=' selected="selected"';}

                    $urlffpr='<option value="'.str_replace(' ','_',$rowfanffpr['id_desci']).'" '.$selectffpr.'>'.$rowfanffpr['nomproduit'].'</option>'.$urlffpr;

                }

           ?>

            <select name="id_desci_pr">

              <option value="">------</option><?php echo $urlffpr?></select>                

            </td>

         </tr>
         
         <tr>
         <td>Nom Image</td>
         <td><input type="text" value="<?php echo (isset($_POST['subimage'])) ? $_POST['titre_descri'] : $frm['titre_descri'] ?>" name="titre_descri"></td>
         
         </tr>


         <tr>

         <td nowrap="nowrap">Select multiple files (Max 10M) :</td>

<td>     
				<input type="file" name="files[]" multiple/>           </td>

        </tr>
            <tr>
            <td></td>
            	<td><input name="subimage" style="width:200px; cursor:pointer;" type="submit" class="ajouter" value="<?php echo $frm["titre_soumet"]?>" /></td>
            </tr>

            </table>

           </form> 

  </div>

</div>

<?php 

}



function affiche_liste_categorie()
{
	GLOBAL $id;
	$pg=$_GET['pg'];

		$query="select * from image ORDER BY (id_image) ASC";

		$result = mysql_query($query)

		or DIE("<div class='error'>Probl&egrave;me de selection des image liens dans la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());



		$nbr_produits = mysql_num_rows($result);

		$nombreDePages = ceil($nbr_produits/NB_PRODUIT_PAR_PAGE_ADMIN);
			if(empty($_GET['pg'])){$pg=1;}
		$pg=$_GET['pg'];	

				if(!empty($pg)){

                    /*  to optimise */

					$pageActuelle = intval($pg);

					if($pageActuelle > $nombreDePages)
					{

                        $pageActuelle = $nombreDePages;
					}
				}
				else{
					 $pageActuelle = 1; // La page actuelle est la n�1

				}
			$premiereEntree = ($pageActuelle-1)*NB_PRODUIT_PAR_PAGE_ADMIN; // On calcul la premi&egrave;re entr&eacute;e � lire
		/*	fin	*/
		$query = $query." LIMIT ".$premiereEntree.", ".NB_PRODUIT_PAR_PAGE_ADMIN;
		$result = mysql_query($query) or DIE('<div class="error">Probl&egrave;me de selection des  de la base donn&eacute;e '. $query . __LINE__ . '.</div>' . MYSQL_ERROR());

		if (mysql_num_rows($result) <= 0){

			echo '<h4 class="alert_success">Aucun image trouver dans la base de donn&eacute;e</h4><br/>';

		}else{
		?>

	<script src="js/jquery.js" type="text/javascript"></script>

<script src="js/main.js" type="text/javascript"></script>

	

<form name="entryfrm" method="post" action="" enctype="multipart/form-data">

  <input type="hidden" name="mode" value="<?php if($_GET['mode']=='modif') echo 'maj';?>" />

  <input type="hidden" name="id" value="<?php echo $_GET['id']?>" />

  <div id="conatainer">

    <div id="Layer1">

      <div id="resultat">

        <table border="0" cellpadding="0" cellspacing="2" width="100%">

          <tr valign="top">

            <td colspan="7"><H3>Liste des images:</H3></td>

          </tr>

          <tr>

            <th><center>

                Action

              </center></th>


            <th><center>

                Url image

              </center></th>

			<th><center>

                Cat&eacute;gorie Liaison image

              </center></th>

          </tr>

          <?php	
		  function getnomcategorielie($io)
		  {
			  $res = mysql_query("select * FROM categorie where id_categorie = $io")

		or DIE("<div class='error'>Probl&egrave;me de selection des image de la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
			$donnec = mysql_fetch_array($res);
			echo $donnec['nom_categorie'];
		  }
		  function getnomproduit($io)
		  {
			  $res = mysql_query("select * FROM produit where id_desci = $io")

		or DIE("<div class='error'>Probl&egrave;me de selection des produits de la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
			$donnec = mysql_fetch_array($res);
			echo $donnec['nomproduit'];
		  }

 		  function getnomcategorielie_pr($io)
		  {
			  $res = mysql_query("select * FROM categorie_projet_realise where id_categorie = $io")

		or DIE("<div class='error'>Probl&egrave;me de selection des image de la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
			$donnec = mysql_fetch_array($res);
			echo $donnec['nom_categorie'];
		  }
		  function getnomproduit_pr($io)
		  {
			  $res = mysql_query("select * FROM produit_projet_realise where id_desci = $io")

		or DIE("<div class='error'>Probl&egrave;me de selection des produits de la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
			$donnec = mysql_fetch_array($res);
			echo $donnec['nomproduit'];
		  }
		  
		  function getnomcategorielie_pc($io)
		  {
			  $res = mysql_query("select * FROM categorie_projet_encour where id_categorie = $io")

		or DIE("<div class='error'>Probl&egrave;me de selection des image de la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
			$donnec = mysql_fetch_array($res);
			echo $donnec['nom_categorie'];
		  }
		  function getnomproduit_pc($io)
		  {
			  $res = mysql_query("select * FROM produit_projet_encour where id_desci = $io")

		or DIE("<div class='error'>Probl&egrave;me de selection des produits de la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
			$donnec = mysql_fetch_array($res);
			echo $donnec['nomproduit'];
		  }


                            while ($donnees = mysql_fetch_array($result))

                            {  

                            ?>

          <tr width="100%">

            <td width="20%"><center>

                <script language=javascript>

                    <!--

                    function test(string,cat,mode,mode2) 

					{ 

                        var chaine = "Etes vous certain de supprimer cette photo?";

                        var result = confirm(chaine); 

                        if(result)

                        {

                            location.replace("multipleimages.php?mode=supp&id=" + string);

                        }	

                        else 

						{

                          location.replace("multipleimages.php");

                        } 

                    }

                    --> 

                    </script>

                   <?php if($_SESSION["statut"] == "admin")

                    {

                    ?>

                <a href="javascript:test(<? echo $donnees['id_image']; echo ",'".$donnees['nom_image']."','".$mode."','".$mode2."'";?>);"><img alt="supprimer" title="supprimer" src="images/icn_trash.png" border="0" /></a>&nbsp;&nbsp;&nbsp; 

              </center>

              <!--Image a selectionner..-->

              <?php 

					}

				?>

            </td>

           

            <td nowrap="nowrap"><center>

               <a href="<?php echo PATH_IMAGE.$donnees['nom_image']?>" target="_blank"> Voir cet image</a>

              </center></td>

			 <td nowrap="nowrap" style="text-transform:capitalize;"><center>

                <? echo $donnees['type']; ?> <?  if($donnees['type']=='categorie') {getnomcategorielie($donnees['id_rubrique']);}else if($donnees['type']=='produit') {getnomproduit($donnees['id_rubrique']);} ?> <?  if($donnees['type']=='categorie_pr') {getnomcategorielie_pr($donnees['id_rubrique']);}else if($donnees['type']=='produit_pr') {getnomproduit_pr($donnees['id_rubrique']);} ?>
                
                <?  if($donnees['type']=='categorie_pc') {getnomcategorielie_pc($donnees['id_rubrique']);}else if($donnees['type']=='produit_pc') {getnomproduit_pc($donnees['id_rubrique']);} ?>

              </center></td>

          </tr>

          <?php	}?>

        </table>

      </div>

      <?php

		

		/*		Partie pagination	*/







		$espace = "<div id='espace'>...</div>";







		$prec = '<div id="page"><a href="?pg='.($pageActuelle-1).$mode.'">Pr&eacute;c</div>';







		$suiv = '<div id="page"><a href="?pg='.($pageActuelle+1).$mode.'">Suiv</div>';







		$pagination = '<div id="pagination">';







		//1- si les nombre de page inf&eacute;rieur � dix  =>		traitement normale







		if($nombreDePages <= 10 ){







			$pagination = '<div id="pagination">';







			if($pageActuelle>1) $pagination.= $prec;







			for($i = 0; $i < $nombreDePages; $i++){







				$pagination .= '<div id="'.((($i+1) == $pageActuelle) ? "pageActive" : "page" ).'"><a href="?pg='.($i+1).$mode.'" ';







				$pagination .= '>'.($i+1).'</a></div>';







			}







			if($pageActuelle<$nombreDePages) $pagination.= $suiv;







		}else







		//2- si la page selectionner appartient au dix premier page 	=>eviter le reaffichage de div du premier page
		if($pageActuelle < 10){
			if($pageActuelle>1) $pagination.= $prec;
			for($i = 0; $i < 10; $i++){
				$pagination .= '<div id="'.((($i+1) == $pageActuelle) ? "pageActive" : "page" ).'"><a href="?pg='.($i+1).$mode.'" ';
	$pagination .= '>'.($i+1).'</a></div>';
			}
			$pagination.= $espace;







			/*	affiche dernier ligne	*/







			$pagination .= '<div id="page"><a href="?pg='.$nombreDePages.$mode.'" ';







			$pagination .= '>'.$nombreDePages.'</a></div>';







			if($pageActuelle<$nombreDePages) $pagination.= $suiv;







		







		}else







		//3- si la page selectionner appartient au dix dernier pages 	=>eviter le reaffichage de div du dernier page







		if($pageActuelle > ($nombreDePages - 10)){







			







			if($pageActuelle>1) $pagination.= $prec;







			/*	affiche premier ligne	*/







			$pagination .= '<div id="page"><a href="?pg=1'.$mode.'" ';







			$pagination .= '>1</a></div>';







			$pagination.= $espace;







			







			for($i = ($nombreDePages - 10); $i <= $nombreDePages; $i++){







				$pagination .= '<div id="'.((($i) == $pageActuelle) ? "pageActive" : "page" ).'"><a href="?pg='.($i).$mode.'" ';







				$pagination .= '>'.($i).'</a></div>';







			}







			if($pageActuelle<$nombreDePages) $pagination.= $suiv;







		}







		else







		//4- si la page selectionner (actuelle) n'appartient ni au dix premier pages ni au dix dernier pages=>	affichage de div du premier page







		{







			$pagination.= $prec;







			/*	affiche premier ligne	*/







			$pagination .= '<div id="page"><a href="?pg=1'.$mode.'" ';







			$pagination .= '>1</a></div>';







			$pagination.= $espace;







			







			for($i = ($pageActuelle - 5); $i < ($pageActuelle + 4); $i++){







				$pagination .= '<div id="'.((($i+1) == $pageActuelle) ? "pageActive" : "page" ).'"><a href="?pg='.($i+1).$mode.'" ';







				$pagination .= '>'.($i+1).'</a></div>';







			}







			







			$pagination.= $espace;







			/*	affiche dernier ligne	*/







			$pagination .= '<div id="page"><a href="?pg='.$nombreDePages.$mode.'" ';







			$pagination .= '>'.$nombreDePages.'</a></div>';







			$pagination.= $suiv;







		}















		$pagination .= '</div>';







        if($nombreDePages > 1){







            echo $pagination;







        }







?>

    </div>

  </div>

</form>

<?php







		}







		/*	fin pagination*/



	}



function affiche_formulaire_ajout_categorie()

{

		GLOBAL $frm,$options;
		$frm["nouveau_mode"] = "inserer";
		$frm["titre_soumet"] = "Select multiple files";
		$frm["nom_categorie"] = "";
		$frm["id_parent"] = "";
		$frm["description"] = "";
		$frm["image"] = "";
		//$this->affiche_arbre_categorie($options);
		$this->affiche_formulaire_categorie("Ajout");
	}

	function inserer_categorie($frm)
	{
		
		
		if(!empty($_FILES['files']) && (!empty($_POST['id_cat']) || !empty($_POST['id_desci']) || !empty($_POST['id_cat_pc']) || !empty($_POST['id_desci_pc']) || !empty($_POST['id_cat_pr']) || !empty($_POST['id_desci_pr'])))
		{
		$errors= array();
	foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){
		$file_name = $key.$_FILES['files']['name'][$key];
		$file_size =$_FILES['files']['size'][$key];
		$file_tmp =$_FILES['files']['tmp_name'][$key];
		$file_type=$_FILES['files']['type'][$key];	
        if($file_size > 800097152){
			$errors[]='File size must be less than 2 MB';
        }		
        
		$qimg3=$file_name;

			if($qimg3==".png")

			{

			$extension='.png';

			}

			elseif($qimg3==".gif")

			{

			$extension='.gif';

			}

			elseif($qimg3==".bmp")

			{

			$extension='.bmp';

			}

			elseif($qimg3==".jpg" || $qimg3==".JPG" || $qimg3==".JPEG" ||  $qimg3==".jpeg")
			{

			$extension='.jpg';

			}
			else
			{
			$extension='.jpg';
			}
			

			$newname=rand();

			$qimgnew3=$newname.$extension;
			
		//$query="INSERT into upload_data (`USER_ID`,`FILE_NAME`,`FILE_SIZE`,`FILE_TYPE`) VALUES('$user_id','$file_name','$file_size','$file_type'); ";
		if(!empty($_POST['id_cat']))
		{
			$id=$_POST['id_cat'];
			$type='categorie';
		}
		if(!empty($_POST['id_desci']))
		{
			$id=$_POST['id_desci'];
			$type='produit';
		}
		if(!empty($_POST['id_cat_pc']))
		{
			$id=$_POST['id_cat_pc'];
			$type='categorie_pc';
		}
		if(!empty($_POST['id_desci_pc']))
		{
			$id=$_POST['id_desci_pc'];
			$type='produit_pc';
		}
		if(!empty($_POST['id_cat_pr']))
		{
			$id=$_POST['id_cat_pr'];
			$type='categorie_pr';
		}
		if(!empty($_POST['id_desci_pr']))
		{
			$id=$_POST['id_desci_pr'];
			$type='produit_pr';
		}
		
		if(!empty($_POST['id_place']) && $_POST['id_place']=='droite')
		{
			$type='endroit';
		}
		if(!empty($_POST['id_place']) && $_POST['id_place']=='gauche')
		{
			$type='engauche';
		}
		
	
			
		
        //$desired_dir="user_data";
		$desired_dir=PATH_IMAGE;
        if(empty($errors)==true)
		{
            if(is_dir($desired_dir)==false){
                mkdir("$desired_dir", 0700);		// Create directory if it does not exist
            }
            if(is_dir("$desired_dir/".$qimgnew3)==false){
                move_uploaded_file($file_tmp,"$desired_dir/".$qimgnew3);
            }else{									// rename the file if another one exist
                $new_dir="$desired_dir/".$qimgnew3.time();
                 rename($file_tmp,$new_dir) ;				
            }
			
			
			$qid = mysql_query("insert into image (id_rubrique,nom_image,titre,type) values ('".$id."','".$qimgnew3."','".str_replace("'","\'",$_POST['titre_descri'])."','".$type."')") or die('<div class="error">Probl&egrave;me d\'insertion de images dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
			
			
		 mysql_query($query);			
        }
		else
		{
                print_r($errors);
        }
    }
	if(empty($error))
	{
		//echo "Success";
		if ($qid) 
		{

			echo "<h4 class='alert_success'>Insertion effectu&eacute;e avec succ&egrave;s</h4>";
			?><script>setTimeout(function(){location.replace("multipleimages.php");},2000);</script><?php
		}
			}
		
		}
		else
		{
				echo "<h4 class='alert_error'>Probléme chargement donn&eacute;es</h4>";
		
		}
				

	}





	function tester_existance_categorie($frm)

	{ 

	//sert pour l'insertion	







		$qid = mysql_query("select nom_chambre FROM image")







		or DIE('<div class="error">Probl&egrave;me de selection de room de la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());







		if ($qid) 

		{

			//tester si la table n'est pas vide



			if(mysql_num_rows($qid) > 0){



		//tester chaque nom_categorie







				while($cat = mysql_fetch_array($qid)){







					if($cat['nom_chambre'] == $frm['nom_chambre']){







						return 1;







					}







				}







			}







			return 0;







		}







	}







	







	function affiche_formulaire_modif_categorie($id){







		GLOBAL $frm,$options;







		







		$result = mysql_query("select * FROM image where id_image = $id")

		or DIE('<div class="error">Probl&egrave;me de selection de room de la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
		if ($result) {

			$frm = mysql_fetch_array($result);

			$frm["nouveau_mode"] = "maj";

			$frm["titre_soumet"] = "Sauvegarder";
			$this->affiche_formulaire_categorie("Modif");

		}

	}

	function maj_categorie($frm, $id)

	{



		

			$afficher = (isset($_POST["hotel_enpomo"])) ? 1 : 0;



			if ($qid) 

			{	

				

				echo "<div class='success'>Mise &agrave; jour effectu&eacute;e avec succ&egrave;s</div>";				

			}





			echo "<div class='retour'><a href='multipleimages.php?mode=modif&id=$id'>Retour</a></div>";

	}

	function supprime_categorie($id)

	{



		//gerer les fils du categorie 

		$res = mysql_query("select * FROM image where id_image = $id")

		or DIE("<div class='error'>Probl&egrave;me de selection des image de la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());

		//Si a des fils

	    if (mysql_num_rows($res) > 0)

		{

			while ($cat_fils = mysql_fetch_array($res) )

			{

			 echo "<h4 class='alert_success'>Image supprim&eacute; avec succ&egrave;s</h4>";

                    //  Supprimer l'ancienne photo

                    if(!empty($cat_fils['nom_image']))

					{

                        @unlink(PATH_IMAGE.$cat_fils['nom_image']);

                        //@unlink(PATH_IMAGE_MINIATURE.$cat_fils['nom_image']);

                    }
					?>
                    <script>setTimeout(function(){location.replace("multipleimages.php");},2000);</script>
                    <?php

			}

		}



//supprime categorie

		$qid = mysql_query("DELETE FROM image WHERE id_image = $id")

		or DIE("<div class='error'>Probl&egrave;me de suppression room de la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());



		if ($qid) 

		{

			//echo "<div class='success'>Suppression Image(s) effectu&eacute;e avec succ&egrave;s</div>";

		}



	}







	function cleartable()

	{







		$mode='&u='.$_GET['u'].'&s='.$_GET['s'];







		$mode2='?u='.$_GET['u'].'&s='.$_GET['s'];







			







        echo '<script language="javascript">







			var chaine = "Etes vous certain de supprimer tout?";







			var result = confirm(chaine); 







			if(result)







			{







				location.replace("multipleimages.php?mode=clearok'.$mode.'");







			}







			else







			{







			location.replace("multipleimages.php'.$mode2.'");







			}







			</script>';	







	}







	function okclear()

	{







	$qid = mysql_query("DELETE FROM image") or die("<div class='error'>Probl&egrave;me de suppression de la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());







				







	echo "<div class='success'>Suppression Total effectu&eacute;e avec succ&egrave;s</div>";







	}



}







?>

