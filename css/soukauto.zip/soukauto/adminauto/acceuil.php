<?php 
session_start();
include("../librairie/x25.php");
$sql="SELECT * FROM users WHERE login='".$_SESSION['adminprestige']."' && activ=1";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);

if(empty($_SESSION['adminprestige']) || empty($row['login']))
	header("Location:index.php");	

?>
<!doctype html>
<html lang="fr">
<head>
	<meta charset="utf-8"/>
	<title>Adminsitration souk auto</title>
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="screen" />
	<!--[if lt IE 9]>
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen" />
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<script src="js/jquery-1.5.2.min.js" type="text/javascript"></script>
	<script src="js/hideshow.js" type="text/javascript"></script>
	<script src="js/jquery.tablesorter.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/jquery.equalHeight.js"></script>
	<script type="text/javascript">
	$(document).ready(function() 
    	{ 
      	  $(".tablesorter").tablesorter(); 
   	 } 
	);
	$(document).ready(function() {

	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content

	//On Click Event
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});

});
</script>
<script type="text/javascript">
    $(function(){
        $('.column').equalHeight();
    });
</script>
</head>
<body>
		<?php include("menu.php");?>
    <!-- end of sidebar -->
	<script language="javascript">
		function activbloc()
		{
			if(document.getElementById("typebilanautre").style.display=='none' && document.getElementById("typebilan").value=="autre")
			{
				document.getElementById("typebilanautre").style.display='block';
				document.getElementById("typebilanautre").style.visibility='visible';
				
				document.getElementById("titlebil").style.display='block';
				document.getElementById("titlebil").style.visibility='visible';

			}
			else
			{
				document.getElementById("typebilanautre").style.display='none';
				document.getElementById("typebilanautre").style.visibility='hidden';
				
				document.getElementById("titlebil").style.display='none';
				document.getElementById("titlebil").style.visibility='hidden';

			}			
	}
	function activcont()
	{
			if(document.getElementById("typecontautre").style.display=='none' && document.getElementById("typecontrat").value=="autre")
			{
				document.getElementById("typecontautre").style.display='block';
				document.getElementById("typecontautre").style.visibility='visible';
				
				document.getElementById("titlecont").style.display='block';
				document.getElementById("titlecont").style.visibility='visible';

			}
			else
			{
				document.getElementById("typecontautre").style.display='none';
				document.getElementById("typecontautre").style.visibility='hidden';
				
				document.getElementById("titlecont").style.display='none';
				document.getElementById("titlecont").style.visibility='hidden';

			}		
	}
	</script>
	<section id="main" class="column">
		
		<h4 class="alert_info">Bienvenu</h4>
		
<!--		<article class="module width_full">
			<header><h3>Stats</h3></header>
			<div class="module_content">
				<article class="stats_graph">
					<img src="http://chart.apis.google.com/chart?chxr=0,0,3000&chxt=y&chs=520x140&cht=lc&chco=76A4FB,80C65A&chd=s:Tdjpsvyvttmiihgmnrst,OTbdcfhhggcTUTTUadfk&chls=2|2&chma=40,20,20,30" width="520" height="140" alt="" />
				</article>
				
				<article class="stats_overview">
					<div class="overview_today">
						<p class="overview_day">Today</p>
						<p class="overview_count">1,876</p>
						<p class="overview_type">Hits</p>
						<p class="overview_count">2,103</p>
						<p class="overview_type">Views</p>
					</div>
					<div class="overview_previous">
						<p class="overview_day">Yesterday</p>
						<p class="overview_count">1,646</p>
						<p class="overview_type">Hits</p>
						<p class="overview_count">2,054</p>
						<p class="overview_type">Views</p>
					</div>
				</article>
				<div class="clear"></div>
			</div>
		</article>
-->        <!-- end of stats article -->
		<!--new reporting-->
        <?php
		$mode=$_GET['mode'];
		if(isset($_POST['submit']))
		{
		  	if(empty($_POST['nom']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ nom est obligatoire</h4>';
			}
		  	if(empty($_POST['prenom']))
			{
				
				echo '<h4 class="alert_error" style="float:left;">Champ prenom est obligatoire</h4>';
			}
		  	if(empty($_POST['typebilan']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ type bilan est obligatoire</h4>';
			}
			if(empty($_POST['typebilanautre']) && $_POST['typebilan']=='autre')
			{
				echo '<h4 class="alert_error" style="float:left;">Champ nom d\'autre bilan est obligatoire</h4>';
				$bilanautre='1';
			}
		  	if(empty($_POST['typecontrat']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ type contrat est obligatoire</h4>';
			}
		  	if(empty($_POST['typecontautre']) && $_POST['typecont']=='autre')
			{
				echo '<h4 class="alert_error" style="float:left;">Champ nom d\'autre contrat est obligatoire</h4>';
				$contratautre='1';
			}
			if(empty($_POST['recodemander']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ reco demander est obligatoire</h4>';
			}
			if(!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['typebilan']) && empty($bilanautre) && !empty($_POST['typecontrat']) && empty($contratautre)  && !empty($_POST['recodemander']))
			{
				/*Insert dans table reporting */
				$day=date("d");
				$mois=date("m");
				$year=date("Y");				
				$heure=date("H:i");
				$qid2 = mysql_query("insert into list_report (id_commercial,nom,prenom,bilan,nombilan_siautre,type_contrat,nomcontrat_siautre,reco_demander,message,day_insert,mois_insert,year_insert,heure_insert) values ('".$_POST['idcommercial']."','".$_POST['nom']."','".$_POST['prenom']."','".$_POST['typebilan']."','".$_POST['typebilanautre']."','".$_POST['typecontrat']."','".$_POST['typecontautre']."','".$_POST['recodemander']."','".$_POST['message']."','".$day."','".$mois."','".$year."','".$heure."')")or DIE('<div class="error">Probl&egrave;me dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
				echo '<h4 class="alert_success">Reporting insérées avec succés</h4>';
				?><script>setTimeout(function(){location.replace("acceuil.php");},2000);</script>
                <?php
			}
		}
		if($mode=='add')
		{
		?>
                  <form name="repo" method="post" action="">
                   <article class="module width_3_quarter">
                    <header><h3>Nouveau reporting</h3></header>
                        <div class="module_content">
                                <fieldset>
                                    <label>Nom Commercial:</label>
                                    <input type="text" value="<?php echo $row['nom'].' '.$row['prenom'];?>" disabled>
                                    <input type="text" value="<?php echo $row['id'];?>" name="idcommercial" style="visibility:hidden; height:2px;">
                                    <label>Nom :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['nom'] : '' ?>" name="nom">
                                         
                                    <label>Prenom :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['prenom'] : '' ?>" name="prenom">
                                </fieldset>
                                <fieldset style="width:48%; float:left; margin-right: 3%;"> 
                                <!-- to make two field float next to one another, adjust values accordingly -->
                                    <label>Bilan</label>
                                    <select style="width:92%;" name="typebilan" id="typebilan" onChange="javascript:activbloc()">
                                    	<option value=""></option>                                    
                                    	<option value="Signe">Signé</option>
                                    	<option value="R2">R2</option>                                        
										<option value="sans_suite">Sans suite </option>                                        
                                        <option value="a_recontacter">A recontacter</option>
                                        <option value="autre">Autre, à préciser</option>
                                    </select>
                                    
                                    <label id="titlebil" style="display:none; visibility:hidden;">Autre Bilan:</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['typebilanautre'] : '' ?>" name="typebilanautre" id="typebilanautre" 
                                    	style="width:80%; display:none; visibility:hidden;">

                                </fieldset>
                                <fieldset style="width:48%; float:left;"> 
                                    <label>Type contrat</label>
                                    <select style="width:92%;" onChange="javascript:activcont()" name="typecontrat" id="typecontrat">
                                    	<option value=""></option>
                                        <option value="mutuelle">Mutuelle</option>
                                        <option value="retraite">Retraité</option>
                                    	<option value="prevoyance">Prevoyance</option>                                        
                                        <option value="autre">Autre, à préciser</option>
                                    </select>
                                    <label id="titlecont" style="display:none; visibility:hidden;">Autre Contrat:</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['typecontautre'] : '' ?>" name="typecontautre" id="typecontautre" 
                                    	style="width:80%; display:none; visibility:hidden;">

                                </fieldset>   
                                <fieldset style="float:left; width:100%">
                                    <label>Reco Demander</label>
                                    <select style="width:92%;" name="recodemander">
                                    	<?php
										for($i=0;$i<=10;$i++)
										{
											if($i==0)
											{
												echo '<option value=""></option>';
											}
											else
											{
											echo ' <option value="'.$i.'">'.$i.'</option>';
											}
										}
										?>
                                    </select>
                                    <label>Commentaire</label>
                                    <textarea rows="6" name="message"><?php echo (isset($_POST['submit'])) ? $_POST['message'] : '' ?></textarea>
                                </fieldset>
							<div class="clear"></div>
                        </div>
                    <footer>
                    <div class="submit_link">
                        <input name="submit" type="submit" value="Publier" class="alt_btn">
                        <input name="reset" type="reset" value="Effacer">
                    </div>
                    </footer>
                </article>
                </form>
		<?php
        }
		else if($mode=='modif')
		{
			$iduser=$row['id'];
			$sqllist="SELECT * FROM list_report WHERE id_repor='".$_GET['i']."' && id_commercial=".$iduser;
			$resultlist=mysql_query($sqllist);
			$rowlist=mysql_fetch_array($resultlist);

		?>
                  <form name="repo" method="post" action="">
                   <article class="module width_3_quarter">
                    <header><h3>Modifier reporting</h3></header>
                        <div class="module_content">
                                <fieldset>
                                    <label>Nom Commercial:</label>
                                    <input type="text" value="<?php echo $row['nom'].' '.$row['prenom'];?>" disabled>
                                    <input type="text" value="<?php echo $row['id'];?>" name="idcommercial" style="visibility:hidden; height:2px;">
                                    <label>Nom :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['nom'] : $rowlist['nom'] ?>" name="nom">
                                         
                                    <label>Prenom :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['prenom'] : $rowlist['prenom'] ?>" name="prenom">
                                </fieldset>
                                <fieldset style="width:48%; float:left; margin-right: 3%;"> 
                                <!-- to make two field float next to one another, adjust values accordingly -->
                                    <label>Bilan :</label>
                                    <select style="width:92%;" name="typebilan" id="typebilan" onChange="javascript:activbloc()">
                                    	<option value="" <?php if($rowlist['bilan']=='') echo 'selected';?>></option>                                    
                                    	<option value="Signe" <?php if($rowlist['bilan']=='Signe') echo 'selected';?>>Signé</option>
                                    	<option value="R2" <?php if($rowlist['bilan']=='R2') echo 'selected';?>>R2</option>                                        
										<option value="sans_suite" <?php if($rowlist['bilan']=='sans_suite') echo 'selected';?>>Sans suite </option>                                        
                                        <option value="a_recontacter" <?php if($rowlist['bilan']=='a_recontacter') echo 'selected';?>>A recontacter</option>
                                        <option value="autre" <?php if($rowlist['bilan']=='autre') echo 'selected';?>>Autre, à préciser</option>
                                    </select>
                                    <label id="titlebil" <?php if($rowlist['bilan']=='autre'){ echo ' style="display:block; visibility:visible;"';}else {echo ' style="display:none; visibility:hidden;"';}?>>Autre Bilan:</label>
                                    <input <?php if($rowlist['bilan']=='autre'){ echo ' style="display:block; visibility:visible;"';}else {echo ' style="display:none; visibility:hidden;"';}?> type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['typebilanautre'] : $rowlist['nombilan_siautre'] ?>" name="typebilanautre" id="typebilanautre" 
                                    	style="width:80%;">

                                </fieldset>
                                <fieldset style="width:48%; float:left;"> 
                                    <label>Type contrat :</label>
                                    <select style="width:92%;" onChange="javascript:activcont()" name="typecontrat" id="typecontrat">
                                    	<option value="" <?php if($rowlist['type_contrat']=='') echo 'selected';?>></option>
                                        <option value="mutuelle" <?php if($rowlist['type_contrat']=='mutuelle') echo 'selected';?>>Mutuelle</option>
                                        <option value="retraite" <?php if($rowlist['type_contrat']=='retraite') echo 'selected';?>>Retraité</option>
                                    	<option value="prevoyance" <?php if($rowlist['type_contrat']=='prevoyance') echo 'selected';?>>Prevoyance</option>                                        
                                        <option value="autre" <?php if($rowlist['type_contrat']=='autre') echo 'selected';?>>Autre, à préciser</option>
                                    </select>
                                    <label id="titlecont" <?php if($rowlist['type_contrat']=='autre'){ echo ' style="display:block; visibility:visible;"';}else {echo ' style="display:none; visibility:hidden;"';}?>>Autre Contrat:</label>
                                    <input <?php if($rowlist['type_contrat']=='autre'){ echo ' style="display:block; visibility:visible;"';}else {echo ' style="display:none; visibility:hidden;"';}?> type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['typecontautre'] : $rowlist['nomcontrat_siautre'] ?>" name="typecontautre" id="typecontautre" style="width:80%;">

                                </fieldset>   
                                <fieldset style="float:left; width:100%">
                                    <label>Reco Demander</label>
                                    <select style="width:92%;" name="recodemander">
                                    	<?php
										for($i=0;$i<=10;$i++)
										{
											if($rowlist['reco_demander']==$i)
											{
												$select='selected';
											}
											else
											{
												$select='';
											}
											/**/
											if($i==0)
											{
												echo '<option value="" '.$select.'></option>';
											}
											else
											{
												echo ' <option value="'.$i.'" '.$select.'>'.$i.'</option>';
											}
										}
										?>
                                    </select>
                                    <label>Commentaire</label>
                                    <textarea rows="6" name="message"><?php echo (isset($_POST['submit'])) ? $_POST['message'] : $rowlist['message'] ?></textarea>
                                </fieldset>
							<div class="clear"></div>
                        </div>
                    <footer>
                    <div class="submit_link">
                        <input name="submit" type="submit" value="Modifier" class="alt_btn">
                        <input name="reset" type="reset" value="Effacer">
                    </div>
                    </footer>
                </article>
                </form>
		<?php
        }
		else
		{
		?>
		<?php /*?><article class="module width_3_quarter">
		<header><h3 class="tabs_involved">Tableau Reporting / jour ou mois</h3>
		<ul class="tabs">
   			<li><a href="#tab1">Journée</a></li>
    		<li><a href="#tab2">Mois</a></li>
		</ul>
		</header>

		<div class="tab_container">
			<div id="tab1" class="tab_content">
			<table class="tablesorter" cellspacing="0"> 
			<thead> 
				<tr align="center"> 
   					<th align="center">N°</th> 
    				<th align="center">Nom & prenom</th> 
    				<th align="center">Bilan</th> 
    				<th align="center">Type contrat</th> 
    				<th align="center">Reco Demander</th> 
    				<th align="center">Actions</th> 
				</tr> 
			</thead> 
			<tbody> 
            <?php 
			$day=date('d');
			$mois=date('m');
			$sql2="SELECT * FROM list_report WHERE day_insert='".$day."' && mois_insert='".$mois."' && id_commercial='".$row['id']."'";
			$result2=mysql_query($sql2);
			$i=1;
			while($row2=mysql_fetch_array($result2))
			{
				if($row2['bilan']=='autre')
				{
					$autrebilan=' (Nom autre bilan: '.$row2['nombilan_siautre'].')';
				}
				else
				{
					$autrebilan='';
				}
				if($row2['type_contrat']=='autre')
				{
					$autrecontrat=' (Nom autre contrat: '.$row2['nomcontrat_siautre'].')';
				}
				else
				{
					$autrecontrat='';
				}
			?>
            <tr> 
                <td align="center"><?php echo $i;?></td> 
                <td align="center"><?php echo $row2['nom'].' '.$row2['prenom'];?></td> 
                <td align="center"><?php echo $row2['bilan'].' '.$autrebilan;?></td> 
                <td align="center"><?php echo $row2['type_contrat'].' '.$autrecontrat;?></td> 
                <td align="center"><?php echo $row2['reco_demander'];?></td>
                <td align="center"><a href="acceuil.php?mode=modif&i=<?php echo $row2['id_repor'];?>"><input type="image" src="images/icn_edit.png" title="Edit"></a><a href="acceuil.php?mode=supp&i=<?php echo $row2['id_repor'];?>"><input type="image" src="images/icn_trash.png" title="Trash"></a></td> 
            </tr> 
              <?php
			  $i++;
				}
			  ?>
			</tbody> 
			</table>
			</div><!-- end of #tab1 -->
			
			<div id="tab2" class="tab_content">
			<table class="tablesorter" cellspacing="0"> 
			<thead> 
				<tr align="center"> 
   					<th align="center">N°</th> 
    				<th align="center">Nom & prenom</th> 
    				<th align="center">Bilan</th> 
    				<th align="center">Type contrat</th> 
    				<th align="center">Reco Demander</th> 
    				<th align="center">Actions</th> 
				</tr> 
			</thead> 
			<tbody> 
				<?php 
			$mois=date('m');
			$year=date('Y');
			$sql3="SELECT * FROM list_report WHERE mois_insert='".$mois."' && year_insert='".$year."' && id_commercial='".$row['id']."'";
			$result3=mysql_query($sql3);
			$j=1;
			while($row3=mysql_fetch_array($result3))
			{
				if($row3['bilan']=='autre')
				{
					$autrebilan3=' (Nom autre bilan: '.$row3['nombilan_siautre'].')';
				}
				else
				{
					$autrebilan3='';
				}
				if($row3['type_contrat']=='autre')
				{
					$autrecontrat3=' (Nom autre contrat: '.$row3['nomcontrat_siautre'].')';
				}
				else
				{
					$autrecontrat3='';
				}
			?>
            <tr> 
                <td align="center"><?php echo $j;?></td> 
                <td align="center"><?php echo $row3['nom'].' '.$row3['prenom'];?></td> 
                <td align="center"><?php echo $row3['bilan'].' '.$autrebilan3;?></td> 
                <td align="center"><?php echo $row3['type_contrat'].' '.$autrecontrat3;?></td> 
                <td align="center"><?php echo $row3['reco_demander'];?></td>
                <td align="center"><input type="image" src="images/icn_edit.png" title="Edit"><input type="image" src="images/icn_trash.png" title="Trash"></td> 
            </tr> 
              <?php
			  $j++;
				}
			  ?> 
			</tbody> 
			</table>

			</div><!-- end of #tab2 -->
			
		</div><!-- end of .tab_container -->
		
		</article><?php */?><!-- end of content manager article -->
		<?php }?>
<!--		<article class="module width_quarter">
			<header><h3>Messages</h3></header>
			<div class="message_list">
				<div class="module_content">
					<div class="message"><p>Pour tout infos merci de contactez l'agence actif assur.</p>
					<p><strong></strong></p></div>
				</div>
			</div>
-->	
<!--		<footer>
				<form class="post_message">
					<input type="text" value="Message" onFocus="if(!this._haschanged){this.value=''};this._haschanged=true;">
					<input type="submit" class="btn_post_message" value=""/>
				</form>
			</footer>
		</article>
        -->
        <!-- end of messages article -->
		
		<div class="clear"></div>
<!--		
		<h4 class="alert_warning">A Warning Alert</h4>
		
		<h4 class="alert_error">An Error Message</h4>
		
		<h4 class="alert_success">A Success Message</h4>
-->		
<!-- end of styles article -->
		<div class="spacer"></div>
	</section>


</body>

</html>