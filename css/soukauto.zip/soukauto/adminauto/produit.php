<?php 
session_start();
include("../librairie/x25.php");
$sql="SELECT * FROM users WHERE login='".$_SESSION['adminprestige']."' && activ=1";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);

if(empty($_SESSION['adminprestige']) || empty($row['login']))
	header("Location:index.php");	

?>
<!doctype html>
<html lang="fr">
<head>
	<meta charset="utf-8"/>
	<title>Adminsitration Souk Auto</title>
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="screen" />
	<!--[if lt IE 9]>
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen" />
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<script src="js/jquery-1.5.2.min.js" type="text/javascript"></script>
	<script src="js/hideshow.js" type="text/javascript"></script>
	<script src="js/jquery.tablesorter.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/jquery.equalHeight.js"></script>
	<script type="text/javascript">
	$(document).ready(function() 
    	{ 
      	  $(".tablesorter").tablesorter(); 
   	 } 
	);
	$(document).ready(function() {

	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content

	//On Click Event
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});

});
</script>
<script type="text/javascript">
    $(function(){
        $('.column').equalHeight();
    });
</script>
</head>
<body>
		<?php include("menu.php");?>
    <!-- end of sidebar -->
	<script language="javascript">
		function activbloc()
		{
			if(document.getElementById("typebilanautre").style.display=='none' && document.getElementById("typebilan").value=="autre")
			{
				document.getElementById("typebilanautre").style.display='block';
				document.getElementById("typebilanautre").style.visibility='visible';
				
				document.getElementById("titlebil").style.display='block';
				document.getElementById("titlebil").style.visibility='visible';

			}
			else
			{
				document.getElementById("typebilanautre").style.display='none';
				document.getElementById("typebilanautre").style.visibility='hidden';
				
				document.getElementById("titlebil").style.display='none';
				document.getElementById("titlebil").style.visibility='hidden';

			}			
	}
	function activcont()
	{
			if(document.getElementById("typecontautre").style.display=='none' && document.getElementById("typecontrat").value=="autre")
			{
				document.getElementById("typecontautre").style.display='block';
				document.getElementById("typecontautre").style.visibility='visible';
				
				document.getElementById("titlecont").style.display='block';
				document.getElementById("titlecont").style.visibility='visible';

			}
			else
			{
				document.getElementById("typecontautre").style.display='none';
				document.getElementById("typecontautre").style.visibility='hidden';
				
				document.getElementById("titlecont").style.display='none';
				document.getElementById("titlecont").style.visibility='hidden';

			}		
	}
	</script>
	<section id="main" class="column">
		<h4 class="alert_info">Bienvenu</h4>
        <?php
		$mode=$_GET['mode'];
		if($mode=='supprimer')
		{
			/*select photo pour delete*/
			$sqllist="SELECT photo_acceuil FROM produit WHERE id_desci='".$_GET['id']."'";
			$resultlist=mysql_query($sqllist);
			$rowlist=mysql_fetch_array($resultlist);
			/*supprimer image de dossier*/
			$name = $rowlist["photo_acceuil"];
			unlink(PATH_IMAGE."$name");
			
			/*delete produit*/
			mysql_query("Delete From produit where id_desci=".$_GET['id']);
			echo '<h4 class="alert_success">Suppression effectu&eacute; avec succ&eacute;s</h4><br/>';
			?><script>setTimeout(function(){location.replace("produit.php");},1500);</script><?php
		}
		if($mode=='supp')
		{
			?>
            <script language=javascript>
            <!--
                var result = confirm("Etes vous certain de supprimer cette produit?"); 
                if(result)
                {
					location.replace("produit.php?mode=supprimer&id="+<?php echo $_GET['i'] ?>);
                }
                else 
				{
                    location.replace("produit.php");
                }
            --> 
            </script>
            <?php
		}
			
		if(isset($_POST['submit']))
		{
		  	if(empty($_POST['nomproduit']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ Titre produit est obligatoire</h4><br/>';
			}
			if(empty($_FILES['photo_acceuil']['name']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ Photo est obligatoire</h4><br/>';
			}
			if(!empty($_POST['nomproduit']) && !empty($_FILES['photo_acceuil']['name']))
			{
				/*Insert dans table reporting */
				if(!empty($_FILES['photo_acceuil']['name']))
				{						
								$tmp_name = $_FILES["photo_acceuil"]["tmp_name"];
								$name = $_FILES["photo_acceuil"]["name"];
								
								move_uploaded_file($tmp_name, PATH_IMAGE."$name");
				}
				$qid2 = mysql_query('insert into produit (cat_pere,nomproduit,prixprod,prixpromoprod,telprod,emailprod,photo_acceuil,petit_description,description) values ("'.$_POST['cat_pere'].'","'.stripslashes($_POST['nomproduit']).'","'.stripslashes($_POST['prixprod']).'","'.stripslashes($_POST['prixpromoprod']).'","'.stripslashes($_POST['telprod']).'","'.stripslashes($_POST['emailprod']).'","'.$_FILES['photo_acceuil']['name'].'","'.htmlspecialchars(stripslashes($_POST['petit_description'])).'","'.htmlspecialchars(stripslashes($_POST['description'])).'")')or DIE('<div class="error">Probl&egrave;me dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
				echo '<h4 class="alert_success">Produit insérées avec succés</h4><br/>';
				?><script>setTimeout(function(){location.replace("produit.php");},2000);</script>
                <?php
			}
		}
		/*Update data*/
		if(isset($_POST['update']))
		{
		  	if(empty($_POST['nomproduit']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ Titre produit est obligatoire</h4><br/>';
			}
		  	if(!empty($_POST['nomproduit']))
			{
				/*Insert produit */
				if(!empty($_FILES['photo_acceuil']['name']))
				{
						$tmp_name = $_FILES["photo_acceuil"]["tmp_name"];
						$name = $_FILES["photo_acceuil"]["name"];
						move_uploaded_file($tmp_name, PATH_IMAGE."$name");
								
						$vf=',photo_acceuil="'.$_FILES['photo_acceuil']['name'].'"';
				}
				$qid2 = mysql_query('update produit set cat_pere="'.$_POST['cat_pere'].'",nomproduit="'.stripslashes($_POST['nomproduit']).'",prixprod="'.stripslashes($_POST['prixprod']).'",prixpromoprod="'.stripslashes($_POST['prixpromoprod']).'",telprod="'.stripslashes($_POST['telprod']).'",emailprod="'.stripslashes($_POST['emailprod']).'",petit_description="'.htmlspecialchars(stripslashes($_POST['petit_description'])).'",description="'.htmlspecialchars(stripslashes($_POST['description'])).'"'.$vf.' where id_desci="'.$_GET['i'].'"')or DIE('<div class="error">Probl&egrave;me dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
				echo '<h4 class="alert_success">Update produit insérées avec succés</h4><br/>';
				?><script>setTimeout(function(){location.replace("produit.php");},2000);</script>
                <?php
			}
		}		
		if($mode=='add')
		{
			function affiche_arbre_categorie($options,$flag=1,$id=0,$firstCategorie=0)
			{
				GLOBAL $options;
				//chercher les categories au racine
				$qid = mysql_query("select * from categorie where id_parent = 0 ORDER BY  `id_categorie` ASC ")	or DIE("<div class='error'>Probl&egrave;me de selection des categories dans la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
			if($qid)
			{
				//tester l'existance d'une resultat au moin
				if (mysql_num_rows($qid) > 0) 
				{
				//parcourir les categories parentes une par une
					while ($cat =  mysql_fetch_array($qid)) 
					{				
						if($firstCategorie == 0)
						{
							$firstCategorie = $cat['id_categorie'];
						}
							$options .= "<option value=\"".$cat['id_categorie']."\">".$cat['nom_categorie']."</option>";
							//pour chaque categorie au racine, on va chercher leur fils (niveau par niveau)
							chercher_fils($options, " &nbsp;'-&nbsp;", $cat['id_categorie'], $id);
					}
				}
		}
		return $options;
	}	
	function chercher_fils($options, $tirer, $id_parent, $id)
	{
		GLOBAL $options;
		$qid = mysql_query("select * from categorie where id_parent = $id_parent")or DIE("<div class='error'>Probl&egrave;me de selection des categories dans la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
		if($qid)
		{
			while ($cat =  mysql_fetch_array($qid)) 
			{
				$options .= "<option value=\"".$cat['id_categorie']."\" ";
				if($cat['id_categorie'] == $id){ $options .= " selected";}
				$options .= " >".$tirer.$cat['nom_categorie']."</option>";
				chercher_fils($options, "&nbsp; &nbsp;".$tirer,$cat['id_categorie'], $id);
			}
		}
	}
	affiche_arbre_categorie($options);
		?>
                  <form name="repo" method="post" action="" enctype="multipart/form-data">
                   <article class="module width_3_quarter">
                    <header>
                      <h3>Liste Produit</h3></header>
                        <div class="module_content">
                                <fieldset>
                                    <label>Nom Categorie :</label>
                                    <select name="cat_pere" size="9" class="htgs">
										<?php echo $options;?>
                                   </select>                                        
                                </fieldset>
                                <fieldset>
     		                        <label>Nom produit :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['nomproduit'] : $rowlist['nomproduit'] ?>" name="nomproduit">
                                    </fieldset>
		                        <fieldset style="float:left; width:100%">
        	                        <label>Prix Produit</label>
            		                <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['prixprod'] : $rowlist['prixprod'] ?>" name="prixprod">
                                    <br/>
								<br/></fieldset>
								<fieldset style="float:left; width:100%">
        	                        <label>Prix promo Produit</label>
            		                <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['prixpromoprod'] : $rowlist['prixpromoprod'] ?>" name="prixpromoprod">
                                    <br/>
								<br/></fieldset>
								<fieldset style="float:left; width:100%">
        	                        <label>Tel Produit</label>
            		                <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['telprod'] : $rowlist['telprod'] ?>" name="telprod">
                                    <br/>
								<br/></fieldset>
								<fieldset style="float:left; width:100%">
        	                        <label>Email Produit</label>
            		                <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['emailprod'] : $rowlist['emailprod'] ?>" name="emailprod">
                                    <br/>
								<br/></fieldset>
		                        <fieldset style="float:left; width:100%">
        	                        <label>Image Produit</label>
            		                <input type="file" value="<?php echo (isset($_POST['submit'])) ? $_POST['photo_acceuil'] : $rowlist['photo_acceuil'] ?>" name="photo_acceuil">
                                    <br/>
								<br/></fieldset>
                                   <fieldset style="float:left; width:100%">
                                    <label>Petit Descrption</label><br/><br/>
                                    <textarea rows="5" name="petit_description" id="petit_description"><?php echo (isset($_POST['submit'])) ? $_POST['petit_description'] : $rowlist['petit_description'] ?></textarea>
                                    <script type="text/javascript">
                                            CKEDITOR.replace( 'petit_description' );
                                        </script>
                                </fieldset>
                          		<fieldset style="float:left; width:100%">
                                    <label>Description</label><br/><br/>
                                    <textarea rows="10" name="description"><?php echo (isset($_POST['submit'])) ? $_POST['description'] : '' ?></textarea>
                                    <script type="text/javascript">
                                            CKEDITOR.replace( 'description' );
                                        </script>
                                </fieldset>
                                
							<div class="clear"></div>
                        </div>
                    <footer>
                    <div class="submit_link">
                        <input name="submit" type="submit" value="Valider" class="alt_btn">
                        <input name="reset" type="reset" value="Effacer">
                    </div>
                    </footer>
                </article>
                </form>
		<?php
        }
		else if($mode=='modif')
		{
			function affiche_arbre_categorie_modif($options,$id)
			{
		
				GLOBAL $options;
				//chercher le categorie p&egrave;re
				$qid = mysql_query("select id_parent from categorie where id_categorie = ".$id) or DIE("<div class='error'>Probl&egrave;me de selection des categories dans la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
				if($qid)
				{			
					//il faut que cette instruction donne une reponse parce que chaque categorie doit avoir une categorie parente (*1)
					if (mysql_num_rows($qid) > 0) 
					{
						$id_parent =  mysql_fetch_array($qid);
					}
				}
				//chercher les categories au racine
				$qid = mysql_query("select * from categorie where id_parent = 0 ")	or DIE("<div class='error'>Probl&egrave;me de selection des categories dans la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
				if($qid)
				{
					//tester l'existance d'une resultat au moin
					if (mysql_num_rows($qid) > 0) 
					{
						//parcourir les categories parentes une par une
						while ($cat =  mysql_fetch_array($qid)) 
						{					
						//tester si ce categorie coincide avec le categorie m&egrave;re
							if($cat['id_categorie'] == $id)
							{
							  $options .= "<option value=\"".$cat['id_categorie']."\" selected>".$cat['nom_categorie']."</option>";
							}
							else
							{
							  $options .= "<option value=\"".$cat['id_categorie']."\">".$cat['nom_categorie']."</option>";
							}
							//pour chaque categorie au racine, on va chercher leur fils (niveau par niveau)
							chercher_fils_modif($options, " &nbsp;'-&nbsp;", $cat['id_categorie'],$id_parent['id_parent']);
						}
					}
				}		
			}	
			function chercher_fils_modif($options, $tirer, $id_parent, $id)
			{
				//	cette fonction diff&eacute;rent de celle qui se trouve dans la classe image	
				GLOBAL $options2;
				$qid = mysql_query("select * from categorie where id_parent = $id_parent")	or DIE("<div class='error'>Probl&egrave;me de selection des categories dans la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());		
				if($qid)
				{			
					while ($cat =  mysql_fetch_array($qid)) 
					{
						if($cat['id_categorie'] == $id)
						{
							$options .= "<option value=\"".$cat['id_categorie']."\" selected>".$tirer.$cat['nom_categorie']."</option>";
						}
						else
						{
							$options .= "<option value=\"".$cat['id_categorie']."\">".$tirer.$cat['nom_categorie']."</option>";
						}
						chercher_fils_modif($options, "&nbsp; &nbsp;".$tirer,$cat['id_categorie'],$id);
					}
				}
			}
			
			$sqllist="SELECT * FROM produit WHERE id_desci='".$_GET['i']."'";
			$resultlist=mysql_query($sqllist);
			$rowlist=mysql_fetch_array($resultlist);
			
			affiche_arbre_categorie_modif($options,$rowlist['cat_pere']);
			?>
                  <form name="repo" method="post" action="" enctype="multipart/form-data">
                   <article class="module width_3_quarter">
                    <header><h3>Modifier Description</h3></header>
                        <div class="module_content">
                        		<fieldset>
                                    <label>Nom Categorie :</label>
                                    <select name="cat_pere" size="9" class="htgs">
										<?php echo $options;?>
                                   </select>                                        
                                </fieldset>
                                <fieldset>
                                <label>Nom produit :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['nomproduit'] : $rowlist['nomproduit'] ?>" name="nomproduit">
                                    </fieldset>
		                        <fieldset style="float:left; width:100%">
        	                        <label>Image Produit</label>
            		                <input type="file" value="<?php echo (isset($_POST['submit'])) ? $_POST['photo_acceuil'] : $rowlist['photo_acceuil'] ?>" name="photo_acceuil">
                                     <br/>
                              <?php if(!empty($rowlist['photo_acceuil']))
									{
									?>
                                      &nbsp;&nbsp;&nbsp;&nbsp;<img src="<?php echo PATH_IMAGE.$rowlist['photo_acceuil'];?>" width="254" height="113" border="0">
                                    <?php
									}
									?>
<br/>
</fieldset>
                                   <fieldset style="float:left; width:100%">
                                    <label>Petit Descrption</label><br/><br/>
                                    <textarea rows="5" name="petit_description" id="petit_description"><?php echo (isset($_POST['submit'])) ? $_POST['petit_description'] : $rowlist['petit_description'] ?></textarea>
                                    <script type="text/javascript">
                                            CKEDITOR.replace( 'petit_description' );
                                        </script>
                                </fieldset>
                          		<fieldset style="float:left; width:100%">
                                    <label>Description</label><br/><br/>
                                    <textarea rows="10" name="description"><?php echo (isset($_POST['submit'])) ? $_POST['description'] : '' ?></textarea>
                                    <script type="text/javascript">
                                            CKEDITOR.replace( 'description' );
                                        </script>
                                </fieldset>
							<div class="clear"></div>
                        </div>
                    <footer>
                    <div class="submit_link">
                        <input name="update" type="submit" value="Modifier" class="alt_btn">
                        <input name="resetupdt" type="reset" value="Effacer">
                    </div>
                    </footer>
                </article>
                </form>
		<?php
        }
		else
		{
		?>
		<article class="module width_3_quarter">
		<header><h3 class="tabs_involved">Tableau Descriptif Page d'acceuil</h3></header>
	      <div class="tab_container">
			<div id="tab1" class="tab_content">
			<table class="tablesorter" cellspacing="0"> 
			<thead> 
				<tr align="center"> 
   					<th align="center">N°</th> 
                    <th align="center">Nom Cat&eacute;gorie</th> 
    				<th align="center" nowrap>Url Produit</th>
                    <th align="center" nowrap>Nom produit</th> 
    				<th align="center">Description</th> 
    				<th align="center" nowrap>Actions</th> 
				</tr> 
			</thead> 
			<tbody> 
            <?php 
			function getnomcategorie($ide)
			{
				$sql3="SELECT * FROM categorie where id_categorie=".$ide;
				$result3=mysql_query($sql3);
				$row3=mysql_fetch_array($result3);
				return($row3['nom_categorie']);
			}
			$sql2="SELECT * FROM produit";
			$result2=mysql_query($sql2);
			$i=1;
			while($row2=mysql_fetch_array($result2))
			{
				if($row2['photo_acceuil']!='')
				{
					$urlimage=PATH_IMAGE.$row2['photo_acceuil'];
				}
				else
				{
					$urlimage='';
				}
			?>
            <tr> 
                <td align="center"><?php echo $i;?></td> 
                <td align="center"><?php echo getnomcategorie($row2['cat_pere']);?></td> 
                <td align="center"><?php echo '<a target="_blank" href="'.$urlimage.'">Voir image produit</a>';?></td> 
                <td align="center"><?php echo $row2['nomproduit'];?></td> 
                <td align="center" style="text-align:center; width:200px;"><?php echo htmlspecialchars_decode(nl2br($row2['description']));?></td>
                <td align="center" nowrap><a href="produit.php?mode=modif&i=<?php echo $row2['id_desci'];?>"><input type="image" src="images/icn_edit.png" title="Edit"></a><a href="produit.php?mode=supp&i=<?php echo $row2['id_desci'];?>"><input type="image" src="images/icn_trash.png" title="Trash"></a></td> 
            </tr> 
              <?php
			  $i++;
				}
			  ?>
			</tbody> 
			</table>
			</div><!-- end of #tab1 -->			
			
		</div><!-- end of .tab_container -->
		
		</article><!-- end of content manager article -->
		<?php }?>
        <!-- end of messages article -->
		
		<div class="clear"></div>
<!-- end of styles article -->
		<div class="spacer"></div>
	</section>


</body>

</html>