<?php session_start();
//Connect to database from here
include("../librairie/x25.php");

//get the posted values
$email=$_GET['m'];


$sql="Update users set activ=1 where email='".$email."'";
$result=mysql_query($sql);
	if(!empty($email))
	{
	echo '<h4 class="alert_success">Compte activ&eacute;</h4>';
	?>
	<script>setTimeout(function(){location.replace("index.php");},4000);</script>
    <?php		
	}

?>