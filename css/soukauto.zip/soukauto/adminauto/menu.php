<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	<link rel="stylesheet" href="css/colorpicker.css" type="text/css" />

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/colorpicker.js"></script>
    <script type="text/javascript" src="js/eye.js"></script>
    <script type="text/javascript" src="js/utils.js"></script>
    <script type="text/javascript" src="js/layout.js?ver=1.0.2"></script>
<header id="header">
		<hgroup>
			<h1 class="site_title"><a href="index.php">Admin. Souk Auto</a></h1>
			<h2 class="section_title">Tableau de bords</h2><div class="btn_view_site"><a href="../index.php" target="_blank" style="float:left;">Acceuil Site</a><a style="float:left;" href="secure.php?logout1">Quitter</a></div>
		</hgroup>
	</header> <!-- end of header bar -->
	
	<section id="secondary_bar">
		<div class="user">
			<p><?php echo $row['nom'].' '.$row['prenom'];?> <!--(<a href="#">3 Messages</a>)--></p>
<!--			 <a class="logout_user" href="#" title="Logout">Logout</a>
-->		</div>
		<div class="breadcrumbs_container">
			<article class="breadcrumbs"><a href="index.php">Tableau G&eacute;n&eacute;ral</a> <div class="breadcrumb_divider"></div></article>
		</div>
	</section><!-- end of secondary bar -->
	<?php 
	function page_courante()
	{
	$fichierCourant = $_SERVER["PHP_SELF"];
	$parties = explode('/', $fichierCourant );
	return trim($parties[count($parties) - 1]);
	}
	$nomcourant=page_courante();
	?>
	<aside id="sidebar" class="column">
        <h3>Listes des annonceurs:</h3>
		<ul class="toggle" <?php if($nomcourant=='slider.php'){ echo 'style="display:block !important;"';} else { echo 'style="display:none;"';}?>>
			<li class="icn_new_article"><a href="annonceur.php?mode=add">Ajouter annonceur</a></li>
			<li class="icn_categories"><a href="annonceur.php">Liste des annonceurs</a></li>
		</ul>
        <h3>Liste Categorie:</h3>
		<ul class="toggle" <?php if($nomcourant=='categorie.php'){ echo 'style="display:block !important;"';} else { echo 'style="display:none;"';}?>>
			<li class="icn_new_article"><a href="categorie.php?mode=add">Ajouter nouvelle Cat&eacute;gorie</a></li>
			<li class="icn_categories"><a href="categorie.php">Liste Cat&eacute;gories</a></li>
		</ul>
		<h3>Liste Produit:</h3>
		<ul class="toggle" <?php if($nomcourant=='produit.php'){ echo 'style="display:block !important;"';} else { echo 'style="display:none;"';}?>>
			<li class="icn_new_article"><a href="produit.php?mode=add">Ajouter nouveau Produit</a></li>
			<li class="icn_categories"><a href="produit.php">Liste Produit</a></li>
		</ul>
        <h3>Les images:</h3>
		<ul class="toggle" <?php if($nomcourant=='multipleimages.php'){ echo 'style="display:block !important;"';} else { echo 'style="display:none;"';}?>>
			<li class="icn_new_article"><a href="multipleimages.php?mode=ajout">Ajouter des images</a></li>
			<li class="icn_categories"><a href="multipleimages.php">Liste Images</a></li>
		</ul>
		<h3>Actualit&eacute;s:</h3>
		<ul class="toggle" <?php if($nomcourant=='news.php'){ echo 'style="display:block !important;"';} else { echo 'style="display:none;"';}?>>
			<li class="icn_new_article"><a href="news.php?mode=add">Ajouter actualit&eacute;</a></li>
            <li class="icn_categories"><a href="news.php">Liste Actualit&eacute;s</a></li>
		</ul>
		<h3>Administrateurs:</h3>
		<ul class="toggle" <?php if($nomcourant=='profil.php'){ echo 'style="display:block !important;"';} else { echo 'style="display:none;"';}?>>
			<li class="icn_profile"><a href="profil.php">Votre Profil</a></li>
			<?php if($_SESSION['statut']=='admin'){?><li class="icn_security"><a href="register.php">Ajouter un administrateur</a></li><?php }?>
			<li class="icn_jump_back"><a href="secure.php?logout1">Logout</a></li>
		</ul>
		
		<footer>
			<hr />
			<p><strong>Copyright &copy; 2022 Fayasolutions</strong></p>
			<p>Designed by <a href="http://www.fayasolutions.tn">Fayasolutions</a></p>
		</footer>
        <div class="spacer"></div>
        <div class="spacer"></div>
	</aside>