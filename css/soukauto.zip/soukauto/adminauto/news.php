<?php 
session_start();
include("../librairie/x25.php");
$sql="SELECT * FROM users WHERE login='".$_SESSION['adminprestige']."' && activ=1";
$result=mysql_query($sql);
$row=mysql_fetch_array($result);

if(empty($_SESSION['adminprestige']) || empty($row['login']))
	header("Location:index.php");	

?>
<!doctype html>
<html lang="fr">
<head>
	<meta charset="utf-8"/>
	<title>Adminsitration Immobiliere le prestige</title>
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="screen" />
	<!--[if lt IE 9]>
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen" />
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<script src="js/jquery-1.5.2.min.js" type="text/javascript"></script>
	<script src="js/hideshow.js" type="text/javascript"></script>
	<script src="js/jquery.tablesorter.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/jquery.equalHeight.js"></script>
	<script type="text/javascript">
	$(document).ready(function() 
    	{ 
      	  $(".tablesorter").tablesorter(); 
   	 } 
	);
	$(document).ready(function() {

	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content

	//On Click Event
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});

});
</script>
<script type="text/javascript">
    $(function(){
        $('.column').equalHeight();
    });
</script>
</head>
<body>
		<?php include("menu.php");?>
    <!-- end of sidebar -->
	<script language="javascript">
		function activbloc()
		{
			if(document.getElementById("typebilanautre").style.display=='none' && document.getElementById("typebilan").value=="autre")
			{
				document.getElementById("typebilanautre").style.display='block';
				document.getElementById("typebilanautre").style.visibility='visible';
				
				document.getElementById("titlebil").style.display='block';
				document.getElementById("titlebil").style.visibility='visible';

			}
			else
			{
				document.getElementById("typebilanautre").style.display='none';
				document.getElementById("typebilanautre").style.visibility='hidden';
				
				document.getElementById("titlebil").style.display='none';
				document.getElementById("titlebil").style.visibility='hidden';

			}			
	}
	function activcont()
	{
			if(document.getElementById("typecontautre").style.display=='none' && document.getElementById("typecontrat").value=="autre")
			{
				document.getElementById("typecontautre").style.display='block';
				document.getElementById("typecontautre").style.visibility='visible';
				
				document.getElementById("titlecont").style.display='block';
				document.getElementById("titlecont").style.visibility='visible';

			}
			else
			{
				document.getElementById("typecontautre").style.display='none';
				document.getElementById("typecontautre").style.visibility='hidden';
				
				document.getElementById("titlecont").style.display='none';
				document.getElementById("titlecont").style.visibility='hidden';

			}		
	}
	</script>
	<script language=javascript>
     function supprmierphoto(id)
		{
             var result = confirm("Etes vous certain de supprimer cette photo?"); 
             if(result)
             {
				location.replace("news.php?mode=supprimerphoto&id="+id);
            }
             else 
			{
               location.replace("news.php?mode=modif&i="+id);
       }
	}
    </script>
	<section id="main" class="column">
		<h4 class="alert_info">Bienvenu</h4>
        <?php
		$mode=$_GET['mode'];
		if($mode=='supprimerphoto')
		{
			/*select photo pour delete*/
			$sqllist="SELECT photo_acceuil FROM news WHERE id_desci='".$_GET['id']."'";
			$resultlist=mysql_query($sqllist);
			$rowlist=mysql_fetch_array($resultlist);
			/*supprimer image de dossier*/
			$name = $rowlist["photo_acceuil"];
			unlink(PATH_IMAGE."$name");
			
			/*delete produit*/
			$qid2 = mysql_query('update news set photo_acceuil="" where id_desci="'.$_GET['id'].'"')or DIE('<div class="error">Probl&egrave;me dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());

			echo '<h4 class="alert_success">Photo supprimer avec succ&eacute;s</h4><br/>';
			?>
			<script>setTimeout(function(){location.replace("news.php?mode=modif&i=<?php echo $_GET['id'];?>");},1000);</script>
			<?php
		}
		if($mode=='supprimer')
		{
			mysql_query("Delete From news where id_desci=".$_GET['id']);
			echo '<h4 class="alert_success">Suppression effectu&eacute; avec succ&eacute;s</h4><br/>';
			?><script>setTimeout(function(){location.replace("news.php");},1500);</script><?php
		}
		if($mode=='supp')
		{
			?>
            <script language=javascript>
            <!--
                var result = confirm("Etes vous certain de supprimer cette news?"); 
                if(result)
                {
					location.replace("news.php?mode=supprimer&id="+<?php echo $_GET['i'] ?>);
                }
                else 
				{
                    location.replace("news.php");
                }
            --> 
            </script>
            <?php
		}
		if(isset($_POST['submit']))
		{
		  	if(empty($_POST['titre_descri']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ Titre news est obligatoire</h4><br/>';
			}
			if(empty($_POST['petit_description']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ petit description est obligatoire</h4><br/>';
			}
			
			if(!empty($_POST['titre_descri']) && !empty($_POST['petit_description']))
			{
				
				/*Insert dans table reporting */
				if(!empty($_FILES['photo_acceuil']['name']))
				{						
						$tmp_name = $_FILES["photo_acceuil"]["tmp_name"];
						$file_name= $_FILES["photo_acceuil"]["type"];
						$qimg3=$file_name;
						if($qimg3=="image/png")
						{
						$extension='.png';
						}
						elseif($qimg3=="image/gif")
						{
						$extension='.gif';
						}
						elseif($qimg3=="image/bmp")
						{
						$extension='.bmp';
						}
						elseif($qimg3=="image/jpg" || $qimg3=="image/JPG" || $qimg3=="image/JPEG" ||  $qimg3=="image/jpeg")
						{
						$extension='.jpg';
						}
						
						$newname=rand();
						$qimgnew3=$newname.$extension;
						$name = $qimgnew3;
					
					move_uploaded_file($tmp_name, PATH_IMAGE."$name");
				}	

				$qid2 = mysql_query('insert into news (titre_descri,photo_acceuil,petit_description,description,date) values ("'.$_POST['titre_descri'].'","'.$name.'","'.htmlspecialchars(stripslashes($_POST['petit_description'])).'","'.htmlspecialchars(stripslashes($_POST['description'])).'","'.date("d/m/Y").'")')or DIE('<div class="error">Probl&egrave;me dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
				echo '<h4 class="alert_success">Actualit&eacute; insérées avec succés</h4><br/>';
				?><script>setTimeout(function(){location.replace("news.php");},2000);</script>
                <?php
			}
		}
		/*Update data*/
		if(isset($_POST['update']))
		{
		  	if(empty($_POST['titre_descri']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ Titre news est obligatoire</h4><br/>';
			}
		  	if(empty($_POST['petit_description']))
			{
				echo '<h4 class="alert_error" style="float:left;">Champ petit description est obligatoire</h4><br/>';
			}
			
			if(!empty($_POST['titre_descri']) && !empty($_POST['petit_description']))
			{
				
				/*Insert dans table reporting */
				if(!empty($_FILES['photo_acceuil']['name']))
				{
						$tmp_name = $_FILES["photo_acceuil"]["tmp_name"];
						$file_name= $_FILES["photo_acceuil"]["type"];
						$qimg3=$file_name;
						if($qimg3=="image/png")
						{
						$extension='.png';
						}
						elseif($qimg3=="image/gif")
						{
						$extension='.gif';
						}
						elseif($qimg3=="image/bmp")
						{
						$extension='.bmp';
						}
						elseif($qimg3=="image/jpg" || $qimg3=="image/JPG" || $qimg3=="image/JPEG" ||  $qimg3=="image/jpeg")
						{
						$extension='.jpg';
						}
						
						$newname=rand();
						$qimgnew3=$newname.$extension;
						$name = $qimgnew3;
						
						move_uploaded_file($tmp_name, PATH_IMAGE."$name");
								
						$vf=',photo_acceuil="'.$name.'"';
				}

				$qid2 = mysql_query('update news set titre_descri="'.$_POST['titre_descri'].'",petit_description="'.htmlspecialchars(stripslashes($_POST['petit_description'])).'",description="'.htmlspecialchars(stripslashes($_POST['description'])).'",date="'.date("d/m/Y").'" '.$vf.' where id_desci="'.$_GET['i'].'"')or DIE('<div class="error">Probl&egrave;me dans la base de donn&eacute;e ' . __LINE__ . '.</div>' . MYSQL_ERROR());
				echo '<h4 class="alert_success">Update Actualit&eacute; insérées avec succés</h4><br/>';
				?><script>setTimeout(function(){location.replace("news.php");},2000);</script>
                <?php
			}
		}
		
		if($mode=='add')
		{
		?>
                  <form name="repo" method="post" action="" enctype="multipart/form-data">
                   <article class="module width_3_quarter">
                    <header>
                      <h3>Module Actualit&eacute;</h3></header>
                        <div class="module_content">
                                <fieldset>
                                    <label>Titre Actualit&eacute; :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['titre_descri'] : $rowlist['titre_descri'] ?>" name="titre_descri">                                         
                                </fieldset>
                                 <fieldset style="float:left; width:100%;">
                                 <label>Image description</label>
                             	 <input type="file" value="<?php echo (isset($_POST['submit'])) ? $_POST['photo_acceuil'] : '' ?>" name="photo_acceuil">
 								</fieldset>
                                <fieldset style="float:left; width:100%">
                                    <label>Petit Descrption</label><br/><br/>
                                    <textarea rows="5" name="petit_description" id="petit_description"><?php echo (isset($_POST['submit'])) ? $_POST['petit_description'] : $rowlist['petit_description'] ?></textarea>
                                    <script type="text/javascript">
                                            CKEDITOR.replace( 'petit_description' );
                                        </script>
                                </fieldset>
                          		<fieldset style="float:left; width:100%">
                                    <label>Description</label><br/><br/>
                                    <textarea rows="10" name="description" id="description"><?php echo (isset($_POST['submit'])) ? $_POST['description'] : $rowlist['description'] ?></textarea>
                                    <script type="text/javascript">
                                            CKEDITOR.replace( 'description' );
                                        </script>
                                </fieldset>
							<div class="clear"></div>
                        </div>
                    <footer>
                    <div class="submit_link">
                        <input name="submit" type="submit" value="Valider" class="alt_btn">
                        <input name="reset" type="reset" value="Effacer">
                    </div>
                    </footer>
                </article>
                </form>
		<?php
        }
		else if($mode=='modif')
		{
			$sqllist="SELECT * FROM news WHERE id_desci='".$_GET['i']."'";
			$resultlist=mysql_query($sqllist);
			$rowlist=mysql_fetch_array($resultlist);
			?>
                  <form name="repo" method="post" action="" enctype="multipart/form-data">
                   <article class="module width_3_quarter">
                    <header><h3>Modifier Actualit&eacute;</h3></header>
                        <div class="module_content">
                                <fieldset>
                                    <label>Titre actualit&eacute; :</label>
                                    <input type="text" value="<?php echo (isset($_POST['submit'])) ? $_POST['titre_descri'] : $rowlist['titre_descri'] ?>" name="titre_descri">                                         
                                </fieldset>   
                                <fieldset style="float:left; width:100%;">
                                <label>Image description</label>
                              	<input type="file" value="<?php echo (isset($_POST['submit'])) ? $_POST['photo_acceuil'] : $rowlist['photo_acceuil'] ?>" name="photo_acceuil">
                                    <br/>
                              <?php if(!empty($rowlist['photo_acceuil']))
									{
									?>
                                       &nbsp;&nbsp;&nbsp;&nbsp;<img src="<?php echo PATH_IMAGE.$rowlist['photo_acceuil'];?>" width="254" height="113" border="0"> <a style="cursor:pointer;" onClick="javascript:supprmierphoto('<?php echo $_GET['i'];?>')">>> Supprimer Photo</a>
                                    <?php
									}
									?>
 								</fieldset>                      
                          		<fieldset style="float:left; width:100%">
                                    <label>Petit Descrption</label><br/><br/>
                                    <textarea rows="5" name="petit_description" id="petit_description"><?php echo (isset($_POST['submit'])) ? $_POST['petit_description'] : $rowlist['petit_description'] ?></textarea>
                                    <script type="text/javascript">
                                            CKEDITOR.replace( 'petit_description' );
                                        </script>
                                </fieldset>
                                <fieldset style="float:left; width:100%">
                                    <label>Descrption</label><br/><br/>
                                    <textarea rows="10" name="description"><?php echo (isset($_POST['submit'])) ? $_POST['description'] : $rowlist['description'] ?></textarea>
                                    <script type="text/javascript">
                                            CKEDITOR.replace( 'description' );
                                        </script>
                                </fieldset>
							<div class="clear"></div>
                        </div>
                    <footer>
                    <div class="submit_link">
                        <input name="update" type="submit" value="Modifier" class="alt_btn">
                        <input name="resetupdt" type="reset" value="Effacer">
                    </div>
                    </footer>
                </article>
                </form>
		<?php
        }
		else
		{
		?>
		<article class="module width_3_quarter">
		<header><h3 class="tabs_involved">Tableau Descriptif Page d'acceuil</h3></header>
	      <div class="tab_container">
			<div id="tab1" class="tab_content">
			<table class="tablesorter" cellspacing="0"> 
			<thead> 
				<tr align="center"> 
   					<th align="center">N°</th> 
                    <th align="center" nowrap>Url image actualite</th>
                    <th align="center" nowrap>Titre descriptif</th> 
    				<th align="center">Petit Description</th>
                    <th align="center">Description</th> 
    				<th align="center" nowrap>Actions</th> 
				</tr> 
			</thead> 
			<tbody> 
            <?php 
			$sql2="SELECT * FROM news";
			$result2=mysql_query($sql2);
			$i=1;
			while($row2=mysql_fetch_array($result2))
			{
				if($row2['photo_acceuil']!='')
				{
					$urlimage=PATH_IMAGE.$row2['photo_acceuil'];
				}
				else
				{
					$urlimage='';
				}
			?>
            <tr style="background-color:#666;"> 
                <td align="center"><?php echo $i;?></td> 
                <td align="center"><?php echo '<a href="'.$urlimage.'">Voir image actualite</a>';?></td> 
                <td align="center"><?php echo $row2['titre_descri'];?></td> 
                <td align="center" style="text-align:justify;"><?php echo htmlspecialchars_decode(nl2br($row2['petit_description']));?></td>
                <td align="center" style="text-align:justify;"><?php echo htmlspecialchars_decode(nl2br($row2['description']));?></td>
                <td align="center" nowrap><a href="news.php?mode=modif&i=<?php echo $row2['id_desci'];?>"><input type="image" src="images/icn_edit.png" title="Edit"></a><a href="news.php?mode=supp&i=<?php echo $row2['id_desci'];?>"><input type="image" src="images/icn_trash.png" title="Trash"></a></td> 
            </tr> 
              <?php
			  $i++;
				}
			  ?>
			</tbody> 
			</table>
			</div><!-- end of #tab1 -->			
		</div><!-- end of .tab_container -->		
		</article><!-- end of content manager article -->
		<?php }?>
        <!-- end of messages article -->
		<div class="clear"></div>
		<!-- end of styles article -->
		<div class="spacer"></div>
	</section>
</body>
</html>