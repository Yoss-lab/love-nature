<!DOCTYPE html>
<html lang="fr">
<?php include("includes/header.php");?>
<body>
    <?php include("includes/menu.php");?>
    <!-- MAIN START -->
    <main class="ps-main">
        <!-- CONTACT START -->
        <div class="ps-contact ps-main-section">
            <section class="container">
                <div class="row ps-categories-details ps-center-content">
                    <div class="col-md-11 col-lg-9 col-xl-8">
                        <div class="ps-center-description">
                            <h6>Have A Query In Mind?</h6>
                            <h4>We Are Everywhere</h4>
                            <p>Consectetur adipisicing eliteiuim set eiusmod tempor incididunt labore etnalom dolore magna aliqua udiminimate veniam quistan norud.</p>
                        </div>
                    </div>
                </div>
                <!-- MAP START -->
                <div class="ps-contact-location">
                    <div id="ps-locationmap2"></div>
                    <div class="ps-our-location">
                        <div>
                            <div class="ps-our-location__shadow">
                            </div>
                            <div class="ps-our-location__content">
                                <h6>Our Location:</h6>
                                <ul class="ps-footer__contact">
                                    <li><a href="javascript:void(0);"><i class="lnr lnr-location"></i> 123 centre, Manar 2 tunisia</a></li>
                                    <li><a href="javascript:void(0);"><i class="lnr lnr-envelope"></i> rentcar090@gmail.com</a></li>
                                    <li><a href="javascript:void(0);"><i class="lnr lnr-phone-handset"></i> (00216) 56 417 050 </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- MAP END -->
                <div class="row ps-gridList ps-newArticles">
                    <!-- CONTACT FORM START -->
                    <div class="col-lg-8">
                        <div class="ps-add-comment">
                            <h5>Feel Free To Contact</h5>
                            <form class="ps-contact-seller ps-comment--form ps-contact--form">
                                <div class="ps-comment--row ps-contact--row">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Full Name*">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Email">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="formGroupExampleInput3" placeholder="Phone">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="formGroupExampleInput4" placeholder="Subject">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Message"></textarea>
                                </div>
                                <button class="btn ps-btn">Submit</button>
                            </form>
                        </div>
                    </div>
                     <!-- CONTACT FORM END -->
                     <!-- SIDEBAR START -->
                    <div class="col-lg-4">
                        <div class="ps-add-comment ps-contact--detail">
                            <h5>Contact Detail</h5>
                            <p>Consectetur adipisicing eliteiuim set eiusmod tempor incididunt labore etnalom dolore magna.</p>
                            <ul class="ps-contact__text">
                                <li><span>Address: </span><address class="mb-0">123 centre,<span class="d-block">Manar 2 Tunisia</span></address></li>
                                <li><span>Phone: </span><a>(00216) 56417050 <span class="d-block">- Fax</span></a></li>
                                <li><span>Email: </span><a>support@soukauto.tn<span class="d-block">info@soukauto.tn</span></a></li>
                                <li><span>Follow: </span>
                                    <ul class="ps-footer__social-media">
                                        <li class="ps-facebook"><a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="ps-twitter"><a href="javascript:void(0);"><i class="fab fa-twitter"></i></a></li>
                                        <li class="ps-linkedin"><a href="javascript:void(0);"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li class="ps-instagram"><a href="javascript:void(0);"><i class="fab fa-instagram"></i></a></li>
                                        <li class="ps-youtube"><a href="javascript:void(0);"><i class="fab fa-youtube"></i></a></li>
                                        <li class="ps-google-plus"><a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- SIDEBAR END -->
                </div>
            </section>
        </div>
        <!-- CONTACT END -->
    </main>
    <!-- MAIN END -->
    <?php include("includes/footer.php");?>
</body>
</html>