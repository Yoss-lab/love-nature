<!DOCTYPE html>
<html lang="fr">
<?php include("includes/header.php");?>
<body>
	<?php include("includes/menu.php");?>
    <!-- MAIN START -->
    <main class="ps-main">
        <!-- FEATURED START -->
        <section class="ps-main-section ps-featured">
            <div class="container">
                <div class="ps-center-content">
                    <div class="ps-center-description ps-featured__description">
                        <h6 class="animate" data-animate="swoopInLeft">Start With Top Quality</h6>
                        <h4 class="animate" data-animate="swoopInRight">Featured Ads</h4>
                        <p class="animate" data-animate="fadeIn">Bonne chance annonce tunisie  etnalom dolore magna aliqua udiminimate veniam quistan norud.</p>
                    </div>
                    <div id="owl-two" class="ps-featured--cards owl-carousel owl-theme">
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/featured/img-01.jpg" class="card-img-top" alt="chercher un telephone">
                                    <div></div>
                                </figure>
                                <span class="ps-tag">Featured</span>
                                <span class="ps-tag--arrow"></span>
                                <div class="card-body">
                                    <h6>D3,149</h6>
                                    <p class="card-text">Brand New Iphone XII For Sale</p>
                                    <span class="d-block"><i class="ti-layers"></i> <a href="javascript:void(0);">Electronics</a></span>
                                    <span><i class="ti-time"></i> <span>Jun 27, 2021</span></span>
                                    <figure><img src="images/user-icon/img-01.jpg" alt="Image Description"></figure>
                                </div>
                                <ul class="list-group">
                                    <li class="list-group-item"><span><i class="ti-map"></i> <a href="javascript:void(0);">Manzeh 9, TN</a></span><a href="javascript:void(0);"><i class="far fa-heart"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/featured/img-02.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <span class="ps-tag">Featured</span>
                                <span class="ps-tag--arrow"></span>
                                <div class="card-body">
                                    <h6>D1650</h6>
                                    <p class="card-text">Galaxy Note 10 Urgent Sale</p>
                                    <span class="d-block"><i class="ti-layers"></i> <a href="javascript:void(0);">Electronics</a></span>
                                    <span><i class="ti-time"></i> <span>Jun 27, 2020</span></span>
                                    <figure><img src="images/user-icon/img-02.png" alt="Image Description"></figure>
                                </div>
                                <ul class="list-group">
                                    <li class="list-group-item"><span><i class="ti-map"></i> <a href="javascript:void(0);">Manar 3, TN</a></span><a href="javascript:void(0);"><i class="far fa-heart"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/featured/img-03.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <span class="ps-tag">Featured</span>
                                <span class="ps-tag--arrow"></span>
                                <div class="card-body">
                                    <h6>D1,200</h6>
                                    <p class="card-text">Mac Air Book Pro, Slightly Used</p>
                                    <span class="d-block"><i class="ti-layers"></i> <a href="javascript:void(0);">Electronics</a></span>
                                    <span><i class="ti-time"></i> <span>Jun 27, 2020</span></span>
                                    <figure><img src="images/user-icon/img-03.jpg" alt="Image Description"></figure>
                                </div>
                                <ul class="list-group">
                                    <li class="list-group-item"><span><i class="ti-map"></i> <a href="javascript:void(0);">Manouba, TN</a></span><a href="javascript:void(0);"><i class="far fa-heart"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/featured/img-04.jpg" class="card-img-top" alt="Pc portable">
                                    <div></div>
                                </figure>
                                <span class="ps-tag">Featured</span>
                                <span class="ps-tag--arrow"></span>
                                <div class="card-body">
                                    <h6>D1,149</h6>
                                    <p class="card-text">Brand New Touch Book For Sale</p>
                                    <span class="d-block"><i class="ti-layers"></i> <a href="javascript:void(0);">Electronics</a></span>
                                    <span><i class="ti-time"></i> <span>Jun 13, 2020</span></span>
                                    <figure><img src="images/user-icon/img-04.jpg" alt="Image Description"></figure>
                                </div>
                                <ul class="list-group">
                                    <li class="list-group-item"><span><i class="ti-map"></i> <a href="javascript:void(0);">Beja, TN</a></span><a href="javascript:void(0);"><i class="far fa-heart"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/featured/img-01.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <span class="ps-tag">Featured</span>
                                <span class="ps-tag--arrow"></span>
                                <div class="card-body">
                                    <h6>$1,149</h6>
                                    <p class="card-text">Brand New Iphone X For Sale</p>
                                    <span class="d-block"><i class="ti-layers"></i> <a href="javascript:void(0);">Electronics</a></span>
                                    <span><i class="ti-time"></i> <span>Jun 27, 2019</span></span>
                                    <figure><img src="images/user-icon/img-01.jpg" alt="Image Description"></figure>
                                </div>
                                <ul class="list-group">
                                    <li class="list-group-item"><span><i class="ti-map"></i> <a href="javascript:void(0);">Manchester, UK</a></span><a href="javascript:void(0);"><i class="far fa-heart"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/featured/img-02.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <span class="ps-tag">Featured</span>
                                <span class="ps-tag--arrow"></span>
                                <div class="card-body">
                                    <h6>$650</h6>
                                    <p class="card-text">Galaxy Note 8 Urgent Sale</p>
                                    <span class="d-block"><i class="ti-layers"></i> <a href="javascript:void(0);">Electronics</a></span>
                                    <span><i class="ti-time"></i> <span>Jun 27, 2019</span></span>
                                    <figure><img src="images/user-icon/img-02.png" alt="Image Description"></figure>
                                </div>
                                <ul class="list-group">
                                    <li class="list-group-item"><span><i class="ti-map"></i> <a href="javascript:void(0);">Manchester, UK</a></span><a href="javascript:void(0);"><i class="far fa-heart"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/featured/img-03.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <span class="ps-tag">Featured</span>
                                <span class="ps-tag--arrow"></span>
                                <div class="card-body">
                                    <h6>$1,200</h6>
                                    <p class="card-text">Mac Air Book Pro, Slightly Used</p>
                                    <span class="d-block"><i class="ti-layers"></i> <a href="javascript:void(0);">Electronics</a></span>
                                    <span><i class="ti-time"></i> <span>Jun 27, 2019</span></span>
                                    <figure><img src="images/user-icon/img-03.jpg" alt="Image Description"></figure>
                                </div>
                                <ul class="list-group">
                                    <li class="list-group-item"><span><i class="ti-map"></i> <a href="javascript:void(0);">Manchester, UK</a></span><a href="javascript:void(0);"><i class="far fa-heart"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="card">
                                <figure>
                                    <img src="images/featured/img-04.jpg" class="card-img-top" alt="Image Description">
                                    <div></div>
                                </figure>
                                <span class="ps-tag">Featured</span>
                                <span class="ps-tag--arrow"></span>
                                <div class="card-body">
                                    <h6>$1,149</h6>
                                    <p class="card-text">Brand New Touch Book For Sale</p>
                                    <span class="d-block"><i class="ti-layers"></i> <a href="javascript:void(0);">Electronics</a></span>
                                    <span><i class="ti-time"></i> <span>Jun 27, 2019</span></span>
                                    <figure><img src="images/user-icon/img-04.jpg" alt="Image Description"></figure>
                                </div>
                                <ul class="list-group">
                                    <li class="list-group-item"><span><i class="ti-map"></i> <a href="javascript:void(0);">Manchester, UK</a></span><a href="javascript:void(0);"><i class="far fa-heart"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- FEATURED END -->

        <!-- CATEGORIES START -->
        <section class="ps-main-section ps-common-categories">
            <div class="container">
                <div class="row">
                    <div class="col-md-11 col-lg-8 col-xl-7">
                        <div class="ps-center-content">
                            <div class="ps-center-description">
                                <h6 class="animate" data-animate="swoopInLeft">Start Exploring With Our</h6>
                                <h4 class="animate" data-animate="swoopInRight">Common Categories</h4>
                                <p class="animate" data-animate="fadeIn">Tunisie annonce bonne chance pour les vendeurs les achéteur et les chercheurs des opportunité .</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                	<?php
			            $qidcat2 = mysql_query("select * from categorie where id_parent = 0 ORDER BY  `id_categorie` ASC") or DIE("<div class='error'>Probl&egrave;me de selection des categories dans la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
			            while($cat2 =  mysql_fetch_array($qidcat2))
			            {
			                if($cat2['photo_acceuil']!='')
			                {
			                    $urlimage2=PATH_IMAGE_AFFICHAGE.$cat2['photo_acceuil'];
			                }
			                else
			                {
			                    $urlimage2='';
			                }
			                $nbprod2=getnbproduit($cat2['id_categorie']);
			        ?>
                    <div class="col-md-5 col-lg-4 col-xl-3">
                        <div class="ps-common-categories__content">
                            <div class="ps-common-categories__img">
                                <figure>
									<?php if(!empty($urlimage2)){echo '<img style="margin: auto;padding-top: 30%;" src="'.$urlimage2.'" alt="'.$cat2['nom_categorie'].'">';}?></figure>
                                <div></div>
                            </div>
                            <div class="ps-common-categories__title">
                                <h6><?php echo $cat2['nom_categorie'];?></h6>
                                <p><?php echo $nbprod2;?> Items</p>
                            </div>
                            <div class="ps-common-categories__hoverbtn">
                                <button class="btn">Show All</button>
                            </div>
                            <div class="ps-common-categories__hoverimg">
                                <figure><?php if(!empty($urlimage2)){echo '<img width="120px" src="'.$urlimage2.'" alt="'.$cat2['nom_categorie'].'">';}?></figure>
                            </div>
                        </div>
                    </div>
                   <?php 
              		}
                    ?>
                </div>
            </div>
        </section>
        <!-- CATEGORIES END -->
        <!-- ARTICLES START -->
        <section class="ps-main-section ps-articles">
            <div class="container">
                <div class="row">
                    <div class="col-md-11 col-lg-8 col-xl-7">
                        <div class="ps-center-content">
                            <div class="ps-center-description">
                                <h6 class="animate" data-animate="swoopInLeft">Latest & Updated</h6>
                                <h4 class="animate" data-animate="swoopInRight">News Articles</h4>
                                <div class="animate" data-animate="fadeIn"><p>Consectetur adipisicing eliteiuim set eiusmod tempor incididunt labore etnalom dolore magna aliqua udiminimate veniam quistan norud.</p></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-lg-4">
                        <div class="card">
                            <figure>
                                <img src="images/articles/img-01.jpg" class="card-img-top" alt="Image Description">
                            </figure>
                            <div class="card-body">
                                <a href="javascript:void(0);">By Admin</a>
                                <h6 class="card-text">Make Money Easy As Pie</h6>
                                <span>Jun 27,2 019</span>
                                <p>Consectetur adipisicing elite aeiuim setiusm tempor incididunt labore etnalom...</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="card">
                            <figure>
                                <img src="images/articles/img-02.jpg" class="card-img-top" alt="Image Description">
                            </figure>
                            <div class="card-body">
                                <a href="javascript:void(0);">By Almana Kurame</a>
                                <h6 class="card-text">Learn Top 10 Tricks To Sell Your Items</h6>
                                <span>Jun 27,2 019</span>
                                <p>Consectetur adipisicing elite aeiuim setiusm tempor incididunt labore etnalom...</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="card">
                            <figure>
                                <img src="images/articles/img-03.jpg" class="card-img-top" alt="Image Description">
                            </figure>
                            <div class="card-body">
                                <a href="javascript:void(0);">By Ibrahim Styne</a>
                                <h6 class="card-text">Things You Should Start Doing Wi...</h6>
                                <span>Jun 27,2 019</span>
                                <p>Consectetur adipisicing elite aeiuim setiusm tempor incididunt labore etnalom Consectetur</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ARTICLES END -->
                <!-- STATUS START -->
        <section class="ps-main-section ps-status">
            <div class="container">
                <div class="ps-center-content">
                    <div class="ps-center-description">
                        <h6 class="animate" data-animate="swoopInLeft">Why We’re Best</h6>
                        <h4 class="animate" data-animate="swoopInRight">Stat Says It All</h4>
                        <p class="animate" data-animate="fadeIn">Bonne chance  eliteiuim set eiusmod tempor incididunt labore etnalom dolore magna aliqua udiminimate veniam quistan norud.</p>
                    </div>
                    <div class="ps-status__content" id="counter">
                        <div class="ps-status__item">
                            <div class="ps-status__img">
                                <figure><img src="images/ps-status/img-01.png" alt="Image Description"></figure>
                            </div>
                            <div class="ps-status__title">
                                <h5><span class="count" data-count="35">0</span>,<span class="count" data-count="6820"></span></h5>
                                <h6>Active Items</h6>
                            </div>
                        </div>
                        <div class="ps-status__item">
                            <div class="ps-status__img">
                                <figure><img src="images/ps-status/img-02.png" alt="Image Description"></figure>
                            </div>
                            <div class="ps-status__title">
                                <h5><span class="count" data-count="99.56%">0</span>%</h5>
                                <h6>User Feedback</h6>
                            </div>
                        </div>
                        <div class="ps-status__item">
                            <div class="ps-status__img">
                                <figure><img src="images/ps-status/img-03.png" alt="Liquuidation tunisie annonces"></figure>
                            </div>
                            <div class="ps-status__title">
                                <h5><span class="count" data-count="45">0</span>,<span class="count" data-count="824"></span>,<span class="count" data-count="89"></span></h5>
                                <h6>Items Sold</h6>
                            </div>
                        </div>
                        <div class="ps-status__item">
                            <div class="ps-status__img">
                                <figure><img src="images/ps-status/img-04.png" alt="Image Description"></figure>
                            </div>
                            <div class="ps-status__title">
                                <h5><span class="count" data-count="12">0</span>,<span class="count" data-count="0"></span><span class="count" data-count="68"></span></h5>
                                <h6>Cup Of Coffee</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- STATUS END -->
        <!-- VIDEO START -->
        <section class="ps-video">
           <a class="ps-video__img" data-rel="prettyPhoto" href="https://youtu.be/XxxIEGzhIG8">
              <figure><img src="images/ps-video/icon/img-01.png" alt="Image Description"></figure>
           </a>
        </section>
        <!-- VIDEO END -->
        <!-- HOW IT WORKS START -->
        <section class="ps-main-section ps-howitworks">
            <div class="container">
                <div class="ps-center-content">
                    <div class="row">
                        <div class="col-md-11 col-lg-8 col-xl-7">
                            <div class="ps-center-description">
                                <h6 class="animate" data-animate="swoopInLeft">We Made It Simple</h6>
                                <h4 class="animate" data-animate="swoopInRight">How It Works?</h4>
                                <p class="animate" data-animate="fadeIn">Bonne chance annonce tunisie vente Achat chercher Emploi service labore etnalom dolore quistan norud.</p>
                            </div>
                        </div>
                    </div>
                    <div class="ps-howitworks__imges">
                        <div class="ps-howitworks__imges__content">
                            <div class="ps-howitworks__img">
                                <figure><img src="images/howit-works/box-down_arrow.png" alt="Image Description"></figure>
                                <div class="ps-howitworks__dashcircle">
                                    <svg>
                                        <circle cx="50%" cy="50%" r="50%"></circle>
                                    </svg>
                                </div>
                            </div>
                            <div class="ps-howitworks__img__description">
                                <h5><span>Search Best Online</span> Products / Items</h5>
                            </div>
                        </div>                     
                        <div class="ps-howitworks__imges__content">
                            <div class="ps-howitworks__img">
                                <figure><img src="images/howit-works/person.png" alt="Image Description"></figure>
                                <div class="ps-howitworks__dashcircle">
                                    <svg>
                                        <circle cx="50%" cy="50%" r="50%"></circle>
                                    </svg>
                                </div>
                            </div>
                            <div class="ps-howitworks__img__description">
                                <h5><span>Contact Direct To</span> Seller User</h5>
                            </div>
                        </div> 
                        <div class="ps-howitworks__imges__content">
                            <div class="ps-howitworks__img">
                                <figure><img src="images/howit-works/star.png" alt="emlpoi disponible"></figure>
                                <div class="ps-howitworks__dashcircle">
                                    <svg>
                                        <circle cx="50%" cy="50%" r="50%"></circle>
                                    </svg>
                                </div>
                            </div>
                            <div class="ps-howitworks__img__description">
                                <h5><span>Leave Your</span> Feedback</h5>
                            </div>
                        </div> 
                        <div class="ps-howitworks__dashline">
                            <svg>
                                <line x1="0" y1="5" x2="100%" y2="5" stroke="black"
                                stroke-dasharray="4 1" />
                            </svg>
                        </div>  
                        <div class="ps-howitworks__arrow1"><figure><img src="images/howit-works/arrow.png" alt="Image Description"></figure></div>
                        <div class="ps-howitworks__arrow2"><figure><img src="images/howit-works/arrow.png" alt="Image Description"></figure></div>
                    </div>
                </div>
            </div>
        </section>
        <!-- HOW IT WORKS END -->

        <!-- INTRO START -->
        <section class="ps-main-section ps-intro">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-xl-6">
                        <div class="ps-intro__img animate" data-animate="fadeInLeft">
                            <figure>
                                <img src="images/buildings.png" alt="Imgae Description">
                            </figure>
                        </div>
                    </div>
                    <div class="col-12 col-xl-6">
                        <div class="ps-intro__description animate" data-animate="fadeInRight">
                            <h2><span>Meilleurs Platform Pour</span> Vente & Achat</h2>
                            <p>Annonce en tunisie Bonne chance pour les vendeurs les acheteurs les chercheurs des opportunités les chercheurs des emplois.</p>
                            <div class="ps-intro__btn">
                                <button class="btn ps-btn ps-intro__btn--fill">Trouvez Plus</button>
                                <button class="btn ps-btn ps-intro__btn--outline ps-outline-btn">Notre Equipe </button>
                            </div>
                        </div>
                    </div> 
                </div>
            </div>     
        </section>
        <!-- INTRO END -->

    </main>
    <!-- MAIN END -->
<?php include("includes/footer.php");?>
</body>
</html>