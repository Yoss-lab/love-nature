﻿<?php 
function getnbproduit($idprod)
{

   $qide = mysql_query("select count(*) from produit where cat_pere = '".$idprod."'") or DIE("<div class='error'>Probl&egrave;me de selection des produits dans la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
   $cate =  mysql_fetch_array($qide);
   return($cate['0']);
}
?>
<meta charset="UTF-8">
	<!-- PRELOADER START -->
    <div class="preloader-outer">
        <figure><img src="images/img-face.png" alt="Image Description">
            <span class="pulse"></span>
        </figure>
    </div>
    <!-- PRELOADER END -->
	<!-- HEADER START -->
    <header class="ps-main-header3">
        <nav>
            <div class="navbar navbar-expand-lg navbar-light ps-navbar">
                <div class="ps-navbar__header">
                    <a href="index.php" class="navbar-brand"><img src="images/logo.png" alt="Tunisie annonce"></a>
                    <div class="ps-header-form">
                        <form class="ps-form ps-main-form">
                            <div class="ps-form__input"><input class="form-control" placeholder="What Are You Looking For?"></div>
                            <div>
                                <div class="ps-geo-location ps-location">
                                    <input type="text" class="form-control" placeholder="Location*">
                                    <a href="javascript:void(0);" class="ps-location-icon ps-index-icon"><i class="ti-target"></i></a>
                                    <a href="javascript:void(0);" class="ps-arrow-icon ps-index-icon"><i class="ti-angle-down"></i></a>
                                    <div class="ps-distance">
                                        <div class="ps-distance__description">
                                            <label for="amountfour">Distance:</label>
                                            <input type="text" id="amountfour" readonly>
                                        </div>                                           
                                        <div id="slider-range-min"></div>
                                    </div>
                                </div>                     
                                <button class="btn ps-btn">Search Now</button>      
                                <button class="btn ps-btn ps-icon"><i class="ti-search"></i></button>              
                            </div>
                        </form>
                        <div class="ps-form--cancel">
                            <a href="javascript:void(0);">Cancel</a>
                            <a href="javascript:void(0);" class="ps-icon"><i class="ti-close"></i></a>
                        </div> 
                        <div class="ps-form-btn">
                            <button class="btn ps-btn">
                                <i class="ti-search"></i>
                            </button>
                        </div>
                    </div>
                    <div id="ps-nav" class="ps-nav navbar-expand-lg">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <i class="lnr lnr-menu"></i>
                        </button>
                        <div class="collapse navbar-collapse ps-navigation" id="navbarNav">
                            <ul class="navbar-nav nav-Js ml-auto ps-nav ps-nav__ul">
                                <li class="ps-menuhover menu-item-has-children page_item_has_children">
                                    <a href="index.php">Accueil</a>
                                </li>
                                <li class="nav-item"><a href="categories.php">Categories</a></li>
                                <li class="nav-item"><a href="contact.php">Contact</a></li>
                                <li class="ps-menuhover menu-item-has-children page_item_has_children">
                                    <a href="javascript:void(0);"><span class="lnr lnr-menu"></span></a>
                                    <ul class="ps-dropdown sub-menu">
                                        <li>
                                            <a href="about.php">About</a>
                                        </li>
                                        <li class="dropdown-divider"></li>
                                        <li class="dropdown-divider"></li>
                                        <li class="ps-menuhover ps-submenuhover menu-item-has-children page_item_has_children">
                                            <a href="javascript:void(0);">Blog<i class="ti-angle-right"></i></a>
                                            <ul class="ps-dropdown ps-submenu sub-menu">
                                                <li class="nav-item"><a href="blog-grid.php">Blog Grid</a></li>                             
                                                <li class="dropdown-divider"></li>
                                                <li class="nav-item"><a href="blog-single.php">Blog Single</a></li>  
                                            </ul>
                                        </li>
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item ps-menuhover ps-submenuhover menu-item-has-children page_item_has_children">
                                            <a href="javascript:void(0);">Listing <i class="ti-angle-right"></i></a>
                                            <ul class="ps-dropdown ps-submenu sub-menu">
                                                <li class="nav-item"><a href="listing-grid.php">Listing Grid</a></li>                             
                                                <li class="dropdown-divider"></li>
                                                <li class="nav-item"><a href="listing-list.php">Listing List</a></li>  
                                                <li class="dropdown-divider"></li>
                                                <li class="nav-item"><a href="listing-single.php">Listing Single</a></li>  
                                            </ul>
                                        </li>
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item"><a href="login.php">Login</a></li>
                                        <li class="dropdown-divider"></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div> 
                    <div class="ps-navbar__userbtn">
                        <div class="ps-headeruser">              
                            <ul class="navbar-nav ps-nav">
                                <li class="nav-item ps-login--btn"><a href="login.php" class="btn ps-btn">Login / Register</a></li>
                                <li class="nav-item dropdown ps-menuhover ps-userlogo">
                                    <a href="javascript:void(0);" id="navbarDropdown4" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <figure class="d-inline-block">
                                            <img src="images/user-logo.jpg" alt="Image Description">
                                        </figure>
                                    <span><i class="fas fa-chevron-down"></i></span>
                                    </a>
                                    <ul class="dropdown-menu ps-dropdown ps-user__dropdown position-absolute" aria-labelledby="navbarDropdown4">
                                        <li class="nav-item"><a class="dropdown-item" href="dashboard-insights.php"><i class="ti-dashboard"></i>Insights</a></li>                             
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item"><a class="dropdown-item" href="dashboard-profile-setting.php"><i class="ti-user"></i>Profile Settings</a></li>
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item"><a class="dropdown-item" href="dashboard-my-ads.php"><i class="ti-align-justify"></i>My Ads</a></li>  
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item"><a class="dropdown-item" href="dashboard-post-ad.php"><i class="ti-settings"></i>Post Ads</a></li>  
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item"><a class="dropdown-item" href="dashboard-offers-messages.php"><i class="ti-email"></i>Offers/Messages</a></li>  
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item"><a class="dropdown-item" href="dashboard-buy-package.php"><i class="ti-shopping-cart"></i>Buy New Packages</a></li>  
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item"><a class="dropdown-item" href="dashboard-payments.php"><i class="ti-user"></i>Payments</a></li>  
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item dropdown ps-menuhover ps-submenuhover">
                                            <a class="dropdown-item" href="javascript:void(0);" id="navbarDropdown5" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-heart"></i>My Favorite <i class="ti-angle-right ps-right"></i>
                                            </a>
                                            <ul class="dropdown-menu ps-dropdown ps-submenu navbar-nav" aria-labelledby="navbarDropdown5">
                                                <li class="nav-item"><a class="dropdown-item" href="dashboard-my-favorite.php">Favorite Listing</a></li>                             
                                                <li class="dropdown-divider"></li>
                                                <li class="nav-item"><a class="dropdown-item" href="javascript:void(0);">Sub Menu</a></li>
                                            </ul>
                                        </li>  
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item"><a class="dropdown-item" href="dashboard-account-setting.php"><i class="ti-bookmark"></i>Account Setting</a></li>  
                                        <li class="dropdown-divider"></li>
                                        <li class="nav-item"><a class="dropdown-item" href="index.php"><i class="ti-shift-right"></i>Logout</a></li>  
                                    </ul>
                                </li>                             
                                <li class="nav-item ps-post--btn"><a href="dashboard-insights.php" class="btn ps-btn">Post Ad</a></li>
                            </ul>
                        </div>
                    </div>          
                </div>
            </div>
        </nav>
    </header>
    <!-- HEADER END -->
	<?php
	if($pageName=='index.php')
	{
	?>
	<!-- BANNER START -->
    <div class="ps-main-banner">
        <div id="owl-first" class="owl-carousel owl-theme">
            <div class="item">
                <div class="ps-banner-img">
                    <figure><img src="images/banner.jpg" alt="Image Description"></figure>
                </div>
            </div>
            <div class="item">
                <div class="ps-banner-img">
                    <figure><img src="images/banner2.jpg" alt="Image Description"></figure>
                </div>
            </div>
            <div class="item">
                <div class="ps-banner-img">
                    <figure><img src="images/banner3.jpg" alt="Image Description"></figure>
                </div>
            </div>
            <div class="item">
                <div class="ps-banner-img">
                    <figure><img src="images/banner4.jpg" alt="Image Description"></figure>
                </div>
            </div>
            <div class="item">
                <div class="ps-banner-img">
                    <figure><img src="images/banner5.jpg" alt="Image Description"></figure>
                </div>
            </div>
            <div class="item">
                <div class="ps-banner-img">
                    <figure><img src="images/banner6.jpg" alt="Bonne Chance Annonce Tunisie"></figure>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-sm-10">
                    <div class="ps-main-banner-content">
                        <div class="ps-main-banner-text animate" data-animate="fadeInLeft">
                            <h1><span>Chercher, Achat & vente</span> That's <span>All We Do</span></h1>
                            <p>Bonne Chance Annonce Tunisie chercher  Vente  & achat Emploi service  tempor incididunt utnae labore etnalom magna aliqua udiminimate</p>        
                        </div>
                        <form class="ps-form animate" data-animate="fadeInRight">
                            <div class="ps-form__input"><input class="form-control" placeholder="Vous chercher quoi?"></div>
                            <div>
                                <div class="ps-geo-location ps-location">
                                    <input type="text" class="form-control" placeholder="Location*">
                                    <a href="javascript:void(0);" class="ps-location-icon ps-index-icon"><i class="ti-target"></i></a>
                                    <a href="javascript:void(0);" class="ps-arrow-icon ps-index-icon"><i class="ti-angle-down"></i></a>
                                    <div class="ps-distance">
                                        <div class="ps-distance__description">
                                            <label for="amountfour">Distance:</label>
                                            <input type="text" id="amountfour" readonly>
                                        </div>                                           
                                        <div id="slider-range-min"></div>
                                    </div>
                                </div>                                  
                                <button class="btn ps-btn">chercher</button>
                            </div>
                        </form>
                        <div class="ps-banner-down-content">
                            <h6 class="animate" data-animate="fadeInTop">Commencer a chercher Categories:</h6>
                            <figure class="animate" data-animate="swing">
                                <img src="images/arrowcurve.png" alt="Image Description">
                            </figure>
                            <div class="ps-banner--line animate" data-animate="fadeInBottom">
                                <div class="ps-banner__line"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>             
        </div>
        <div id="owl-one" class="ps-slider owl-carousel owl-theme">
            <?php
            $qidcat = mysql_query("select * from categorie where id_parent = 0 ORDER BY  `id_categorie` ASC") or DIE("<div class='error'>Probl&egrave;me de selection des categories dans la base de donn&eacute;e " . __LINE__ . '.<div>' . MYSQL_ERROR());
            while($cat =  mysql_fetch_array($qidcat))
            {
                if($cat['photo_acceuil']!='')
                {
                    $urlimage=PATH_IMAGE_AFFICHAGE.$cat['photo_acceuil'];
                }
                else
                {
                    $urlimage='';
                }
                $nbprod=getnbproduit($cat['id_categorie']);
            ?>
            <div class="item">
                <div class="ps-slider--category">
                    <div class="ps-slider--circle">
                        <figure><?php if(!empty($urlimage)){echo '<img src="'.$urlimage.'" alt="'.$cat['nom_categorie'].'">';}?></figure>
                        <div></div>
                    </div>
                    <div class="ps-category__title">
                        <h6><?php echo $cat['nom_categorie'];?></h6>
                        <p><?php echo $nbprod;?> Items</p>
                    </div>
                </div>
            </div>
            <?php 
            }
            ?>
        </div>
    </div>
    <!-- BANNER END -->
	<?php 
	}
	else
	{
	?>
	<!-- BANNER START -->
    <div class="ps-main-banner">
        <div class="ps-banner-img3">
            <div class="ps-dark-overlay2">
                <div class="container">
                    <div class="ps-banner-contentv3">
                        <h4>We are Always Happy To Serve</h4>
                        <p><a href="index.php">Home</a> <span><i class="ti-angle-right"></i></span> <?php echo ucfirst(str_replace('.php','',$pageName));?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- BANNER END -->
	<?php 
	}
	?>
