<div class="ps-dashboard-sidebar">
    <div class="ps-dashboard-sidebar__user">
        <figure><img src="images/insights/user-img.jpg" alt="Image Description"></figure>
        <div class="ps-seller__description">
            <h6><?php echo $row['nom'].' '.$row['prenom'];?></h6>
            <div class="ps-h5">Status: 
                <?php if($row['activ']=="1")
                {?>
                <a data-toggle="collapse" href="#collapseUser" role="button" aria-expanded="false">
                    <span><em class="ps-online"></em><i class="fa fa-sort-down"></i></span><em>Online</em> 
                </a>
                <?php
                }
                else
                {
                ?>
                <a data-toggle="collapse" href="#collapseUser" role="button" aria-expanded="false">
                    <span><em class="ps-offline"></em><i class="fa fa-sort-down"></i></span><em>offline</em> 
                </a>

                <?php
                 } 
                ?>
                <div class="collapse" id="collapseUser">
                    <a href="javascript:void(0);"><span class="ps-online"></span><em>Online</em></a>
                    <a href="javascript:void(0);"><span class="ps-away"></span><em>Away</em></a>
                    <a href="javascript:void(0);"><span class="ps-busy"></span><em>Busy</em></a>
                    <a href="javascript:void(0);"><span class="ps-offline"></span><em>Offline</em></a>
                </div>
            </div>
        </div>
        <div class="ps-dashboard-sidebar__edit"><a href="javascript:void(0);"><i class="ti-pencil"></i></a></div>
    </div>
    <ul>
        <li><a href="dashboard-insights.php" class="ps-user-dhb"><i class="ti-dashboard"></i> <span>Insights</span> </a></li>
        <li><a href="dashboard-profile-setting.php"><i class="ti-user"></i> <span>Profile Settings</span> </a></li>
        <li><a href="dashboard-my-ads.php"><i class="ti-align-justify"></i> <span>My Ads</span> </a></li>
        <li><a href="dashboard-post-ad.php"><i class="ti-settings"></i> <span>Post Ad</span> </a></li>
        <li><a href="dashboard-offers-messages.php"><i class="ti-email"></i> <span>Offers/messages</span> </a></li>
        <li><a href="dashboard-payments.php"><i class="ti-user"></i> <span>Payments</span> </a></li>
        <li><a href="logout.php?logoutacc"><i class="ti-shift-right"></i> <span>Logout</span> </a></li>
    </ul>
</div>
<div class="ps-gridList__ad ps-dashboard-img">
    <a href="javascript:void(0);"><figure><img src="images/ad-img.jpg" alt="Image Description"></figure></a>
    <span>Advertisement  255px X 255px</span>
</div>