<?php 
include("librairie/x25.php");
$pageName = basename($_SERVER['PHP_SELF']);
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bonne Chance Annonce Tunisie</title>
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
	<link rel="icon" href="images/favicon.png" type="image/x-icon">
<?php if($pageName!='index.php') {?>

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/fontawesome/fontawesome-all.css">
	<link rel="stylesheet" href="css/linearicons.css">
	<link rel="stylesheet" href="css/themify-icons.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/prettyPhoto.css">
    <link rel="stylesheet" href="css/dashboard.css">
	<link rel="stylesheet" href="css/transitions.css">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/dashboard-responsive.css">
<?php } else {?>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/fontawesome/fontawesome-all.css">
    <link rel="stylesheet" href="css/linearicons.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/prettyPhoto.css">
    <link rel="stylesheet" href="css/transitions.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/responsive.css">
<?php }?>
<style>
/* Alerts */
.alert_info {
display: block;
width: 95%;
margin: 20px 3% 0 3%;
margin-top: 20px;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background: #B5E5EF url(../images/icn_alert_info.png) no-repeat;
background-position: 10px 10px;
border: 1px solid #77BACE;
color: #082B33;
padding: 10px 0;
text-indent: 40px;
font-size: 14px;}

.alert_warning {
display: block;
width: 95%;
margin: 20px 3% 0 3%;
margin-top: 20px;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background: #F5F3BA url(../images/icn_alert_warning.png) no-repeat;
background-position: 10px 10px;
border: 1px solid #C7A20D;
color: #796616;
padding: 10px 0;
text-indent: 40px;
font-size: 14px;}

.alert_error {
display: block;
width: 95%;
margin: 20px 3% 0 3%;
margin-top: 20px;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background: #F3D9D9 url(../images/icn_alert_error.png) no-repeat;
background-position: 10px 10px;
border: 1px solid #D20009;
color: #7B040F;
padding: 10px 0;
text-indent: 40px;
font-size: 14px;}

.alert_success {
display: block;
width: 95%;
margin: 20px 3% 0 3%;
margin-top: 20px;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
background: #E2F6C5 url(../images/icn_alert_success.png) no-repeat;
background-position: 10px 10px;
border: 1px solid #79C20D;
color: #32510F;
padding: 10px 0;
text-indent: 40px;
font-size: 14px;}


</style>
</head>
