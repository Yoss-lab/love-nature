﻿<?php
$db_host = "localhost";
$db_username = "fayasolu_u896de";
$db_password = "c$-?Er1LPDT)";
$db_name = "fayasolu_basau20";

$connection = mysql_connect($db_host, $db_username, $db_password);

if (!$connection) {

	echo "Probleme de connexion MySQL<br/>";

}

$selection_de_la_base = mysql_select_db($db_name,$connection);

if (!$selection_de_la_base) {

	echo "Probleme de selection de la base";

}
	
/*      MENU CATEGORIE      */
define('NOMBRE_NIVEAU_SOUS_CATEGORIE', 2);
/*pour ajouter du niveau il faut ajouter
 * un css pour le nouveau niveau
 * et le code appropri� (getCss)*/

/*		Module Pagination	*/	
define('DEFAULT_CHARSET', 'windows-1256');
define('NB_PRODUIT_PAR_PAGE', 4);
define('NB_PRODUIT_PAR_PAGE_ADMIN',15);
define('NB_LYCEES_PAR_PAGE',10);
define('SEUIL_PAGINATION_DEB', 3);
define('SEUIL_PAGINATION', 5);

/*		Module miniature	*/
//define('PATH_IMAGE', 'upload_catalogue/');
//define('PATH_IMAGE_MINIATURE', 'upload_catalogue/miniature/');
define('PATH_IMAGE', '../upload_phototheque/');
define('PATH_IMAGE_AFFICHAGE', 'upload_phototheque/');


define('PATH_IMAGE_MINIATURE', '../upload_phototheque/miniature/');
define('LARGEUR_MINIATURE', 80);
define('HAUTEUR_MINIATURE', 100);

/*		Module actualit�	*/
define('PATH_IMAGE_NEWS', 'upload/');		//	upload_news

?>