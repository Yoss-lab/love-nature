<!--develloped by razouane aymen-->
<?php 

if($_POST["envoi"]==1)
{

	//$TO = "razouane@gmail.com";
	$TO = "contact@immobiliere-le-prestige.com";

	if (get_magic_quotes_gpc()){

		$nom = stripslashes(htmlentities(trim($_POST['nom'])));

		$prenom = stripslashes(htmlentities(trim($_POST['prenom'])));

		$tel = stripslashes(htmlentities(trim($_POST['tel'])));

		$code = stripslashes(htmlentities(trim($_POST['code'])));
		
		$ville = stripslashes(htmlentities(trim($_POST['ville'])));

		$societe = stripslashes(htmlentities(trim($_POST['societe'])));

		$adresse = stripslashes(htmlentities(trim($_POST['adresse'])));

		$expediteur = stripslashes(htmlentities(trim($_POST['email'])));
	
		$choix = stripslashes(htmlentities(trim($_POST['choix'])));

		$check1 = stripslashes(htmlentities(trim($_POST['check1'])));

		$prix = stripslashes(htmlentities(trim($_POST['prix'])));

		$lieu = stripslashes(htmlentities(trim($_POST['lieu'])));
		
		$secteur = stripslashes(htmlentities(trim($_POST['secteur'])));

		$message = stripslashes(htmlentities(trim($_POST['message'])));

	}

	else{  

		$nom = htmlentities(trim($_POST['nom']));

		$prenom = htmlentities(trim($_POST['prenom']));

		$tel = htmlentities(trim($_POST['tel']));

		$code = htmlentities(trim($_POST['code']));

		$ville = htmlentities(trim($_POST['ville']));

		$societe = htmlentities(trim($_POST['societe']));

		$adresse = htmlentities(trim($_POST['adresse']));

		$expediteur = htmlentities(trim($_POST['email']));
		
		$choix = htmlentities(trim($_POST['choix']));

		$check1 = htmlentities(trim($_POST['check1']));

		$prix = htmlentities(trim($_POST['prix']));

		$lieu = htmlentities(trim($_POST['lieu']));
		
		$secteur = htmlentities(trim($_POST['secteur']));

		$message = htmlentities(trim($_POST['message']));

	}



	if (empty($nom) || empty($prenom) || empty($expediteur) || empty($tel) || empty($choix) || empty($check1) || empty($prix) || empty($lieu) || empty($secteur)  || empty($message))

	{
		?><script languege="javascript">
		
				document.getElementById("blocktexte").style.display="block";
				document.getElementById("contact").style.display="block";
				document.getElementById("produit").style.display='none';
				document.getElementById('presentation').style.display='none';
				document.getElementById('service').style.display='none';
				document.getElementById('prod').className='liena';
				document.getElementById('serv').className='liena';
				document.getElementById('presen').className='liena';
				document.getElementById('sousmenu').style.display='none';
			</script>
            <?php
		$alert = "<div class='warning'>Tous les champs doivent &ecirc;tre renseign&eacute;s</div>";

		

	}else{



		/* Expression r�guli�re permettant de v�rifier si le format d'une adresse e-mail est correct */

		$regex_mail = '/^[-+.\w]{1,64}@[-.\w]{1,64}\.[-.\w]{2,6}$/i';   



		/* On v�rifie que le format de l'e-mail est correct */ 

		if (!preg_match($regex_mail, $expediteur)){  

			$alert = "<div class='warning'>L adresse \"".$expediteur."\" n est pas valide</div>



"; 

		}else{



			/* Expression r�guli�re permettant de v�rifier qu'aucun en-t�te n'est ins�r� dans nos champs */

			$regex_head = '/[\n\r]/';   



			/* On v�rifie qu'il n'y a aucun header dans les champs */ 

			if (preg_match($regex_head, $expediteur) || preg_match($regex_head, $nom) || preg_match($regex_head, $subject)){

				$alert = "<div class='infos'>En-t&ecirc;tes interdites dans les champs du formulaire.</div>";

			}else{

				/* envoi de l'e-mail */

				$message_final="Bonjour,<br/>Je voudrais bien prendre information <br/>Nom: ".$nom."<br/>Prenom: ".$prenom."<br/>Tel: ".$tel."<br/>Email: ".$expediteur."<br/>societe: ".$societe."<br/>Adresse & ville: ".$adresse." ".$ville."<br/>code postal: ".$code."<br/>Message: ".$message."<br/>Votre demande concerne: ".$check1." avec un prix de ".$prix." de type: ".$choix." &agrave; ".$lieu." secteur ".$secteur."<br/><br/>Immobiliere le prestige";				

				$from  = "From:$expediteur\n";

				$from .= "MIME-version: 1.0\n";

				$from .= "Content-type: text/html; charset= iso-8859-1\n";

				$subject='Demande d\'information sur un Bien immobiliere sur notre site';			

				mail($TO,$subject,$message_final,$from);

				$envoyer = 1;
				?>
				<script languege="javascript">		
					document.getElementById("blocktexte").style.display="block";
					document.getElementById("contact").style.display="block";
					document.getElementById("produit").style.display='none';
					document.getElementById('presentation').style.display='none';
					document.getElementById('service').style.display='none';
					document.getElementById('prod').className='liena';
					document.getElementById('serv').className='liena';
					document.getElementById('presen').className='liena';
					document.getElementById('sousmenu').style.display='none';
				</script>
				<?php
				echo "<div class='success'>Votre Email a &eacute;t&eacute; envoy&eacute; avec succ&eacute;s.</div>";

			}  

		}



	}

	/* On affiche l'erreur s'il y en a une */ //elle affiche les erreurs pour les deux cas regex & champs vides

	if (!empty($alert))

	{

		echo $alert;

	}



}



?>
<!-- copyright 2010 develloped by razouane aymen Fayasolutions.com-->
