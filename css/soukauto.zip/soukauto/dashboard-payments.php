<!DOCTYPE html>
<html lang="fr">
<?php include("includes/header.php");?>
<body>
    <?php include("includes/menu.php");?>
    <!-- MAIN START -->
    <main class="ps-main">
        <section class="ps-main-section">
            <div class="container">
                <div class="row">
                    <!-- SIDEBAR START -->
                    <div class="col-lg-4">
                        <div class="ps-dashboard-sidebar">
                            <div class="ps-dashboard-sidebar__user">
                                <figure><img src="images/insights/user-img.jpg" alt="Image Description"></figure>
                                <div class="ps-seller__description">
                                    <h6>Lorina Statham</h6>
                                    <div class="ps-h5">Status: 
                                        <a data-toggle="collapse" href="#collapseUser" role="button" aria-expanded="false">
                                            <span><em class="ps-online"></em><i class="fa fa-sort-down"></i></span><em>Online</em> 
                                        </a>
                                        <div class="collapse" id="collapseUser">
                                            <a href="javascript:void(0);"><span class="ps-online"></span><em>Online</em></a>
                                            <a href="javascript:void(0);"><span class="ps-away"></span><em>Away</em></a>
                                            <a href="javascript:void(0);"><span class="ps-busy"></span><em>Busy</em></a>
                                            <a href="javascript:void(0);"><span class="ps-offline"></span><em>Offline</em></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="ps-dashboard-sidebar__edit"><a href="javascript:void(0);"><i class="ti-pencil"></i></a></div>
                            </div>
                            <ul>
                                <li><a href="dashboard-insights.php"><i class="ti-dashboard"></i> <span>Insights</span> </a></li>
                                <li><a href="dashboard-profile-setting.php"><i class="ti-user"></i> <span>Profile Settings</span> </a></li>
                                <li><a href="dashboard-my-ads.php"><i class="ti-align-justify"></i> <span>My Ads</span> </a></li>
                                <li><a href="dashboard-post-ad.php"><i class="ti-settings"></i> <span>Post Ad</span> </a></li>
                                <li><a href="dashboard-offers-messages.php"><i class="ti-email"></i> <span>Offers/messages</span> </a></li>
                                <li><a href="dashboard-buy-package.php" class="ps-active--line"><i class="ti-shopping-cart"></i> <span>Buy New Packages</span> </a></li>
                                <li><a href="dashboard-payments.php" class="ps-user-dhb"><i class="ti-user"></i> <span>Payments</span> </a></li>
                                <li>
                                    <a data-toggle="collapse" href="#collapsenew" role="button" aria-expanded="false"><i class="ti-heart"></i> <span>My Favorite</span> <span class="ps-right"><i class="ti-angle-right"></i></span> </a>
                                    <ul class="collapse" id="collapsenew">
                                        <li><a href="dashboard-my-favorite.php"><span>Favorite Listing</span></a></li>
                                        <li><a href="javascript:void(0);"><span>Sub Menu</span></a></li>
                                    </ul>
                                </li>
                                <li><a href="dashboard-account-setting.php"><i class="ti-bookmark"></i> <span>Account & Privacy Settings</span> </a></li>
                                <li><a href="index-2.php"><i class="ti-shift-right"></i> <span>Logout</span> </a></li>
                            </ul>
                        </div>
                        <div class="ps-gridList__ad ps-dashboard-img">
                            <a href="javascript:void(0);"><figure><img src="images/ad-img.jpg" alt="Image Description"></figure></a>
                            <span>Advertisement  255px X 255px</span>
                        </div>
                    </div>
                    <!-- SIDEBAR END -->
                    <div class="col-lg-8 ps-dashboard-user">
                        <!-- PACKAGE TIME START -->
                        <div class="ps-package">
                            <div class="ps-package__expire">
                                <h6>Your Package Expire in:</h6>
                                <em>Standard Package</em>
                                <a href="javascript:void(0);">Renew Now<i class="fas fa-angle-right"></i></a>
                                <span><i class="ti-time"></i></span>
                            </div>
                            <div class="ps-package__time ps-days">
                                <h5>0</h5>
                                <span>Days</span>
                            </div>
                            <div class="ps-package__time ps-hours">
                                <h5>0</h5>
                                <span>Hours</span>
                            </div>
                            <div class="ps-package__time ps-minutes">
                                <h5>0</h5>
                                <span>Minutes</span>
                            </div>
                            <div class="ps-package__time ps-seconds">
                                <h5>0</h5>
                                <span>Seconds</span>
                            </div>
                        </div>
                        <!-- PACKAGE TIME END -->
                        <!-- PAYMENT DETAILS START -->
                        <div class="ps-posted-ads">
                            <div class="ps-posted-ads__heading">
                                <h5>Payments</h5>
                                <label class="ps-sort">
                                    <select class="form-control">
                                        <option selected="" hidden="">Show:</option>
                                        <option>All</option>
                                        <option>Half</option>
                                    </select>
                                </label>
                            </div>
                            <div class="ps-items-heading">
                                <h6>Invoice Id</h6><h6>Purchase Date</h6><h6>Actions</h6>
                            </div>
                            <div>
                                <ul class="ps-payments-content">
                                    <li>
                                        <div>
                                            <div class="ps-posted-ads__title">
                                                <h6>Invoice Id</h6>
                                                <div>
                                                    <figure><img src="images/payments/img-01.png" alt="Images Description"></figure>
                                                    <div class="ps-description">
                                                        <h5>8TECzHuhPy</h5>
                                                        <h6>Title: Basic Package</h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ps-posted-ads__status">
                                                <h6>Purchase Date</h6>
                                                <h6>Jun 27, 2019</h6>
                                            </div>
                                            <div class="ps-posted-ads__actions">
                                                <h6>Actions</h6>
                                                <span><a href="javascript:void(0);"><i class="ti-eye"></i> View</a><span>/</span><a href="javascript:void(0);"><i class="ti-printer"></i> Print</a></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div>
                                            <div class="ps-posted-ads__title">
                                                <h6>Invoice Id</h6>
                                                <div>
                                                    <figure><img src="images/payments/img-01.png" alt="Images Description"></figure>
                                                    <div class="ps-description">
                                                        <h5>xgE67NS2nt</h5>
                                                        <h6>Title: Standard Package</h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ps-posted-ads__status">
                                                <h6>Purchase Date</h6>
                                                <h6>May 13, 2019</h6>
                                            </div>
                                            <div class="ps-posted-ads__actions">
                                                <h6>Actions</h6>
                                                <span><a href="javascript:void(0);"><i class="ti-eye"></i> View</a><span>/</span><a href="javascript:void(0);"><i class="ti-printer"></i> Print</a></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div>
                                            <div class="ps-posted-ads__title">
                                                <h6>Invoice Id</h6>
                                                <div>
                                                    <figure><img src="images/payments/img-01.png" alt="Images Description"></figure>
                                                    <div class="ps-description">
                                                        <h5>RbNs3u6hs4</h5>
                                                        <h6>Title: Extended Package</h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ps-posted-ads__status">
                                                <h6>Purchase Date</h6>
                                                <h6>Apr 12, 2019</h6>
                                            </div>
                                            <div class="ps-posted-ads__actions">
                                                <h6>Actions</h6>
                                                <span><a href="javascript:void(0);"><i class="ti-eye"></i> View</a><span>/</span><a href="javascript:void(0);"><i class="ti-printer"></i> Print</a></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div>
                                            <div class="ps-posted-ads__title">
                                                <h6>Invoice Id</h6>
                                                <div>
                                                    <figure><img src="images/payments/img-01.png" alt="Images Description"></figure>
                                                    <div class="ps-description">
                                                        <h5>ZeEq8XnPV9</h5>
                                                        <h6>Title: Standard Package</h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ps-posted-ads__status">
                                                <h6>Purchase Date</h6>
                                                <h6>Mar 10, 2019</h6>
                                            </div>
                                            <div class="ps-posted-ads__actions">
                                                <h6>Actions</h6>
                                                <span><a href="javascript:void(0);"><i class="ti-eye"></i> View</a><span>/</span><a href="javascript:void(0);"><i class="ti-printer"></i> Print</a></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div>
                                            <div class="ps-posted-ads__title">
                                                <h6>Invoice Id</h6>
                                                <div>
                                                    <figure><img src="images/payments/img-01.png" alt="Images Description"></figure>
                                                    <div class="ps-description">
                                                        <h5>hGYUW8pLfZ</h5>
                                                        <h6>Title: Extended Package</h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ps-posted-ads__status">
                                                <h6>Purchase Date</h6>
                                                <h6>Feb 11, 2019</h6>
                                            </div>
                                            <div class="ps-posted-ads__actions">
                                                <h6>Actions</h6>
                                                <span><a href="javascript:void(0);"><i class="ti-eye"></i> View</a><span>/</span><a href="javascript:void(0);"><i class="ti-printer"></i> Print</a></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div>
                                            <div class="ps-posted-ads__title">
                                                <h6>Invoice Id</h6>
                                                <div>
                                                    <figure><img src="images/payments/img-01.png" alt="Images Description"></figure>
                                                    <div class="ps-description">
                                                        <h5>v7DwqmFQ2Q</h5>
                                                        <h6>Title: Extended Package</h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ps-posted-ads__status">
                                                <h6>Purchase Date</h6>
                                                <h6>Jan 09, 2019</h6>
                                            </div>
                                            <div class="ps-posted-ads__actions">
                                                <h6>Actions</h6>
                                                <span><a href="javascript:void(0);"><i class="ti-eye"></i> View</a><span>/</span><a href="javascript:void(0);"><i class="ti-printer"></i> Print</a></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div>
                                            <div class="ps-posted-ads__title">
                                                <h6>Invoice Id</h6>
                                                <div>
                                                    <figure><img src="images/payments/img-01.png" alt="Images Description"></figure>
                                                    <div class="ps-description">
                                                        <h5>Cc3GH2EJNh</h5>
                                                        <h6>Title: Standard Package</h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ps-posted-ads__status">
                                                <h6>Purchase Date</h6>
                                                <h6>Dec 13, 2018</h6>
                                            </div>
                                            <div class="ps-posted-ads__actions">
                                                <h6>Actions</h6>
                                                <span><a href="javascript:void(0);"><i class="ti-eye"></i> View</a><span>/</span><a href="javascript:void(0);"><i class="ti-printer"></i> Print</a></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div>
                                            <div class="ps-posted-ads__title">
                                                <h6>Invoice Id</h6>
                                                <div>
                                                    <figure><img src="images/payments/img-01.png" alt="Images Description"></figure>
                                                    <div class="ps-description">
                                                        <h5>T4yjv6QfPm</h5>
                                                        <h6>Title: Basic Package</h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ps-posted-ads__status">
                                                <h6>Purchase Date</h6>
                                                <h6>Nov 10, 2018</h6>
                                            </div>
                                            <div class="ps-posted-ads__actions">
                                                <h6>Actions</h6>
                                                <span><a href="javascript:void(0);"><i class="ti-eye"></i> View</a><span>/</span><a href="javascript:void(0);"><i class="ti-printer"></i> Print</a></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div>
                                            <div class="ps-posted-ads__title">
                                                <h6>Invoice Id</h6>
                                                <div>
                                                    <figure><img src="images/payments/img-01.png" alt="Images Description"></figure>
                                                    <div class="ps-description">
                                                        <h5>Pjp59AyFJA</h5>
                                                        <h6>Title: Basic Package</h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ps-posted-ads__status">
                                                <h6>Purchase Date</h6>
                                                <h6>Oct 06, 2018</h6>
                                            </div>
                                            <div class="ps-posted-ads__actions">
                                                <h6>Actions</h6>
                                                <span><a href="javascript:void(0);"><i class="ti-eye"></i> View</a><span>/</span><a href="javascript:void(0);"><i class="ti-printer"></i> Print</a></span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <div class="ps-page">
                                    <div class="ps-button-left">
                                        <button class="btn ps-btn"><span class="lnr lnr-chevron-left"></span></button>
                                    </div>
                                    <div class="ps-button-num">
                                        <button class="btn ps-btn"><span>1</span></button>
                                        <button class="btn ps-btn ps-active"><span>2</span></button>
                                        <button class="btn ps-btn"><span>3</span></button>
                                        <button class="btn ps-btn"><span>4</span></button>
                                        <button class="btn ps-btn"><span>...</span></button>
                                        <button class="btn ps-btn"><span>50</span></button>
                                    </div>
                                    <div class="ps-button-right">
                                        <button class="btn ps-btn"><span class="lnr lnr-chevron-right"></span></button>
                                    </div>
                                </div>
                            </div>
                            <div class="ps-no-ads">
                                <div>
                                    <figure><img src="images/nothing.png" alt="Image Description"></figure>
                                    <h5>No Payments Found :(</h5>
                                    <h6>Click “Buy Now” button below to buy a package</h6>
                                    <button class="btn ps-btn">Buy Now</button>
                                </div>
                            </div>
                        </div>
                        <!-- PAYMENT DETAILS END -->
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!-- MAIN END -->
    <?php include("includes/footer.php");?>
</body>
</html>