<!DOCTYPE html>
<html lang="fr">
<?php include("includes/header.php");?>
<body>
    <?php include("includes/menu.php");?>
    <!-- MAIN START -->
    <main class="ps-main">
        <section class="ps-main-section">
            <div class="container">
                <div class="row">
                    <!-- SIDEBAR START -->
                    <div class="col-lg-4 animate" data-animate="fadeInLeft">
                        <div class="ps-dashboard-sidebar">
                            <div class="ps-dashboard-sidebar__user">
                                <figure><img src="images/insights/user-img.jpg" alt="Image Description"></figure>
                                <div class="ps-seller__description">
                                    <h6>Lorina Statham</h6>
                                    <div class="ps-h5">Status: 
                                        <a data-toggle="collapse" href="#collapseUser" role="button" aria-expanded="false">
                                            <span><em class="ps-online"></em><i class="fa fa-sort-down"></i></span><em>Online</em> 
                                        </a>
                                        <div class="collapse" id="collapseUser">
                                            <a href="javascript:void(0);"><span class="ps-online"></span><em>Online</em></a>
                                            <a href="javascript:void(0);"><span class="ps-away"></span><em>Away</em></a>
                                            <a href="javascript:void(0);"><span class="ps-busy"></span><em>Busy</em></a>
                                            <a href="javascript:void(0);"><span class="ps-offline"></span><em>Offline</em></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="ps-dashboard-sidebar__edit"><a href="javascript:void(0);"><i class="ti-pencil"></i></a></div>
                            </div>
                            <ul>
                                <li><a href="dashboard-insights.php"><i class="ti-dashboard"></i> <span>Insights</span> </a></li>
                                <li><a href="dashboard-profile-setting.php"><i class="ti-user"></i> <span>Profile Settings</span> </a></li>
                                <li><a href="dashboard-my-ads.php"><i class="ti-align-justify"></i> <span>My Ads</span> </a></li>
                                <li><a href="dashboard-post-ad.php"><i class="ti-settings"></i> <span>Post Ad</span> </a></li>
                                <li><a href="dashboard-offers-messages.php"><i class="ti-email"></i> <span>Offers/messages</span> </a></li>
                                <li><a href="dashboard-buy-package.php" class="ps-active--line"><i class="ti-shopping-cart"></i> <span>Buy New Packages</span> </a></li>
                                <li><a href="dashboard-payments.php"><i class="ti-user"></i> <span>Payments</span> </a></li>
                                <li>
                                    <a data-toggle="collapse" href="#collapsenew" role="button" aria-expanded="false"><i class="ti-heart"></i> <span>My Favorite</span> <span class="ps-right"><i class="ti-angle-right"></i></span> </a>
                                    <ul class="collapse" id="collapsenew">
                                        <li><a href="dashboard-my-favorite.php"><span>Favorite Listing</span></a></li>
                                        <li><a href="javascript:void(0);"><span>Sub Menu</span></a></li>
                                    </ul>
                                </li>
                                <li><a href="dashboard-account-setting.php" class="ps-user-dhb"><i class="ti-bookmark"></i> <span>Account & Privacy Settings</span> </a></li>
                                <li><a href="index-2.php"><i class="ti-shift-right"></i> <span>Logout</span> </a></li>
                            </ul>
                        </div>
                        <div class="ps-gridList__ad ps-dashboard-img">
                            <a href="javascript:void(0);"><figure><img src="images/ad-img.jpg" alt="Image Description"></figure></a>
                            <span>Advertisement  255px X 255px</span>
                        </div>
                    </div>
                    <!-- SIDEBAR END -->
                    <!-- MAIN CONTENT START-->
                    <div class="col-lg-8 ps-dashboard-user animate" data-animate="fadeInRight">
                        <!-- CHANGE PASSWORD START -->
                        <div class="ps-posted-ads ps-profile-setting">
                            <div class="ps-posted-ads__heading">
                                <h5>Change Password</h5>
                                <p>Click “Save Changes” to update</p>
                                <button class="btn ps-btn">Save Changes</button>
                            </div>
                            <div class="ps-profile-setting__content ps-account-save">
                                <form>
                                    <input type="password" class="form-control" placeholder="Old Password*">
                                    <input type="password" class="form-control" placeholder="New Password*">
                                    <input type="password" class="form-control" placeholder="Retype Password*">
                                </form>
                            </div>
                        </div>
                        <!-- CHANGE PASSWORD END -->
                        <!-- ACCOUNT & PRIVACY SETTING START -->
                        <div class="ps-posted-ads ps-profile-setting">
                            <div class="ps-posted-ads__heading">
                                <h5>Account & Privacy Settings</h5>
                                <p>Click “Save Changes” to update</p>
                                <button class="btn ps-btn">Save Changes</button>
                            </div>
                            <div class="ps-profile-setting__content ps-account-setting">
                                <p>Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua aut enim ad minim veniamac quis nostrud exercitation ullamco laboris.</p>
                                <div class="row no-gutters">
                                    <div class="col-md-6">
                                        <div class="ps-account-checkbox">
                                            <div class="ps-on-off">
                                                <input type="checkbox" id="hide1" name="contactForm">
                                                <label for="hide1">
                                                    <i></i>
                                                </label>
                                            </div>
                                            <p>Make my profile public</p>
                                        </div>
                                        <div class="ps-account-checkbox">
                                            <div class="ps-on-off">
                                                <input type="checkbox" id="hide2" name="contactForm">
                                                <label for="hide2">
                                                    <i></i>
                                                </label>
                                            </div>
                                            <p>Share my profile photo</p>
                                        </div>
                                        <div class="ps-account-checkbox">
                                            <div class="ps-on-off">
                                                <input type="checkbox" id="hide3" name="contactForm">
                                                <label for="hide3">
                                                    <i></i>
                                                </label>
                                            </div>
                                            <p>Show my client feedback</p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="ps-account-checkbox">
                                            <div class="ps-on-off">
                                                <input type="checkbox" id="hide4" name="contactForm">
                                                <label for="hide4">
                                                    <i></i>
                                                </label>
                                            </div>
                                            <p>Make my profile searchable</p>
                                        </div>
                                        <div class="ps-account-checkbox">
                                            <div class="ps-on-off">
                                                <input type="checkbox" id="hide5" name="contactForm">
                                                <label for="hide5">
                                                    <i></i>
                                                </label>
                                            </div>
                                            <p>Disable my account temporarily</p>
                                        </div>
                                        <div class="ps-account-checkbox">
                                            <div class="ps-on-off">
                                                <input type="checkbox" id="hide6" name="contactForm">
                                                <label for="hide6">
                                                    <i></i>
                                                </label>
                                            </div>
                                            <p>Enable/ Disable</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ACCOUNT & PRIVACY SETTING END -->
                        <!-- CHANGE PASSWORD FORM START -->
                        <div class="ps-posted-ads ps-profile-setting ps-account">
                            <div class="ps-posted-ads__heading">
                                <h5>Deactivate Account</h5>
                                <p>Click “Deactivate” to Shutdown Account</p>
                                <button class="btn ps-btn">Deactivate</button>
                            </div>
                            <div class="ps-profile-setting__content">
                                <form class="ps-contact-seller ps-comment--form">
                                    <div class="ps-comment--row">
                                        <div class="form-group">
                                            <input type="password" class="form-control" id="formGroupExampleInput" placeholder="Enter Password*">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control" id="formGroupExampleInput2" placeholder="Retype Password*">
                                        </div>
                                    </div>
                                    <div class="form-group ps-form">
                                        <div class="ps-select ps-sort">
                                            <select class="chosen-select locations form-control" data-placeholder="Country" name="locations">
                                                <option value="Location">Location*</option>
                                                <option value="Tunis">Tunis</option>
                                                <option value="Sfax">Sfax</option>
                                                <option value="Sousse">Sousse</option>
                                                <option value="Bizerte">Bizerte</option>
                                                <option value="Mednine">Mednine</option>
                                            </select>
                                        </div> 
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-control" placeholder="Description"></textarea>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- CHANGE PASSWORD FORM END -->
                    </div>
                    <!-- MAIN CONTENT END -->
                </div>
            </div>
        </section>
    </main>
    <!-- MAIN END -->
    <?php include("includes/footer.php");?>
</body>
</html>