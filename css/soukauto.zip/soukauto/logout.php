<?php session_start();
// if session is not set redirect the user
if(empty($_SESSION['Souser20']))
	header("Location:index.php");	
//if logout then destroy the session and redirect the user
elseif(isset($_GET['logoutacc']))
{
	session_destroy();
	header("Location:index.php");
}
else
{	
	header("Location:dashboard-insights.php");
}
?>